function greet(name: string): string {
    return `Hello, ${name}!`;
}
const Message: string = greet("World");
console.log(Message);

