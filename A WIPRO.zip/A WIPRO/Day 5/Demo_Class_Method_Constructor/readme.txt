In this demo we are going to implement clasees, function and constructor
class devlaration
constructor
public/private/protected
readonly, static member
methods
inheritance and method overrriding

We have to follow below steps :
Step 1: Creating a folder with below files 
    person.ts 
    index.html 
    main.ts 
    tsconfig.json 
Step 2: After compiling above ts file we will get corresponding JS file 
    main.js