// courseCategory.ts
export enum CourseCategory {
  DEVELOPMENT = "Development",
  DESIGN = "Design",
  MARKETING = "Marketing",
  BUSINESS = "Business"
}
