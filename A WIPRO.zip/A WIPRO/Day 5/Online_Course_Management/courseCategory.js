"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourseCategory = void 0;
// courseCategory.ts
var CourseCategory;
(function (CourseCategory) {
    CourseCategory["DEVELOPMENT"] = "Development";
    CourseCategory["DESIGN"] = "Design";
    CourseCategory["MARKETING"] = "Marketing";
    CourseCategory["BUSINESS"] = "Business";
})(CourseCategory || (exports.CourseCategory = CourseCategory = {}));
