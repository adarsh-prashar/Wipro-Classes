function greet(name) {
    return "Hello, ".concat(name, "!");
}
var Message = greet("World");
console.log(Message);
