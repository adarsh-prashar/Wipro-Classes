# Day 8 — MongoDB Assignment (BookVerse)

Contents:
- bookverse_assignment_day8.js  : Mongo shell commands (indexes & aggregation)
- connectAtlas.js              : Node.js sample connection script
- seed_data.json               : Small sample data (JSON) for quick tests
- screenshots/                 : Placeholder images for required screenshots
- README.pdf                   : This file in PDF format (for submission)
- assignment_manifest.txt      : Short manifest

Instructions:
1. Load seed data using mongoimport or MongoDB Compass.
   Example: mongoimport --uri "<ATLAS_URI>/BookVerseCloudDB" --collection books --file seed_books.json --jsonArray
2. Run the JS script in mongo shell to create indexes and run aggregation queries:
   - mongosh bookverse_assignment_day8.js
3. Replace the connection string in connectAtlas.js with your Atlas URI or set env var MONGODB_ATLAS_URI and run:
   - node connectAtlas.js

Screenshots to capture for submission:
- Index creation & explain() before/after
- Aggregation outputs (average ratings, top 3 books, authors with >2 books, total points)
- MongoDB Atlas dashboard & connection success message

Notes:
- Replace placeholder ObjectId strings in seed_data.json with real ObjectId values if importing via Compass.
- The sample data file uses Mongo shell Extended JSON for ObjectIds ($oid). Tools like mongoimport support this format.

Good luck! — Generated automatically.
