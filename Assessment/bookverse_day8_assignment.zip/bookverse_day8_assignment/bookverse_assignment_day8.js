// Day 8 — MongoDB Assignment
// Indexing | Aggregation | Atlas
// This script contains index creation commands and aggregation pipelines for BookVerseDB.
// Run in mongo shell (mongo or mongosh). Adjust DB name if using Atlas.

use("BookVerseDB"); // change to BookVerseCloudDB on Atlas if required

// INDEXES
db.books.createIndex({ genre: 1 });
db.books.createIndex({ authorId: 1 });
db.books.createIndex({ "ratings.score": 1 });

// Bonus compound index:
db.books.createIndex({ genre: 1, publicationYear: -1 });

// Explain before/after (example)
printjson(db.books.find({ genre: "Fiction" }).explain("executionStats"));

// AGGREGATION PIPELINES

// 1) Average rating per book
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
  { $sort: { avgRating: -1 } }
]);

// 2) Top 3 highest-rated books
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
  { $sort: { avgRating: -1 } },
  { $limit: 3 }
]);

// 3) Count number of books per genre
db.books.aggregate([
  { $group: { _id: "$genre", totalBooks: { $sum: 1 } } },
  { $sort: { totalBooks: -1 } }
]);

// 4) Authors with more than 2 books
db.books.aggregate([
  { $group: { _id: "$authorId", bookCount: { $sum: 1 } } },
  { $match: { bookCount: { $gt: 2 } } },
  { $lookup: { from: "authors", localField: "_id", foreignField: "_id", as: "authorDetails" } },
  { $unwind: "$authorDetails" },
  { $project: { _id: 0, authorName: "$authorDetails.name", bookCount: 1 } }
]);

// 5) Total reward points (sum of all ratings) by each author
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$authorId", totalPoints: { $sum: "$ratings.score" } } },
  { $lookup: { from: "authors", localField: "_id", foreignField: "_id", as: "authorInfo" } },
  { $unwind: "$authorInfo" },
  { $project: { _id: 0, authorName: "$authorInfo.name", totalPoints: 1 } },
  { $sort: { totalPoints: -1 } }
]);

// Optional: drop an index example
// db.books.dropIndex({ "ratings.score": 1 });
