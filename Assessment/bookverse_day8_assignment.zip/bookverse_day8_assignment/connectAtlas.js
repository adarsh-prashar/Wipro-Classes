

const { MongoClient } = require('mongodb');

const uri = "mongodb+srv://adarsh:Adar123@cluster0.abcd1.mongodb.net/BookVerseCloudDB?retryWrites=true&w=majority";

const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function run() {
  try {
    await client.connect();
    const db = client.db('BookVerseCloudDB');
    console.log('✅ Connected to MongoDB Atlas, DB:', db.databaseName);

    const sample = await db.collection('books').find().limit(3).toArray();
    console.log('Sample books (limit 3):', sample);
  } catch (err) {
    console.error('Connection error:', err);
  } finally {
    await client.close();
  }
}

run();
