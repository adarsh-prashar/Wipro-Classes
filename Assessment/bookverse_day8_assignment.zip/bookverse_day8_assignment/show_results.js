const data = require('./seed_data.json');

console.log('\n=== INDEXES ===');
console.log('Creating indexes on books collection:');
console.log('{ genre: 1 }');
console.log('{ authorId: 1 }');
console.log('{ "ratings.score": 1 }');
console.log('{ genre: 1, publicationYear: -1 }');

console.log('\n=== AGGREGATION RESULTS ===');

console.log('\n1) Average rating per book:');
const avgRatings = data.books.map(book => {
    const avg = book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length;
    return { _id: book.title, avgRating: avg };
}).sort((a, b) => b.avgRating - a.avgRating);
console.log(avgRatings);

console.log('\n2) Top 3 highest-rated books:');
console.log(avgRatings.slice(0, 3));

console.log('\n3) Books per genre:');
const genreCounts = {};
data.books.forEach(book => {
    genreCounts[book.genre] = (genreCounts[book.genre] || 0) + 1;
});
console.log(Object.entries(genreCounts).map(([genre, count]) => ({ _id: genre, totalBooks: count })));

console.log('\n4) Authors with more than 2 books:');
const authorCounts = {};
data.books.forEach(book => {
    authorCounts[book.authorId.$oid] = (authorCounts[book.authorId.$oid] || 0) + 1;
});
const authorsWithManyBooks = Object.entries(authorCounts)
    .filter(([_, count]) => count > 2)
    .map(([authorId, count]) => {
        const author = data.authors.find(a => a._id.$oid === authorId);
        return { authorName: author.name, bookCount: count };
    });
console.log(authorsWithManyBooks);

console.log('\n5) Total reward points by author:');
const authorPoints = {};
data.books.forEach(book => {
    const authorId = book.authorId.$oid;
    const points = book.ratings.reduce((sum, r) => sum + r.score, 0);
    authorPoints[authorId] = (authorPoints[authorId] || 0) + points;
});
const authorPointsList = Object.entries(authorPoints)
    .map(([authorId, points]) => {
        const author = data.authors.find(a => a._id.$oid === authorId);
        return { authorName: author.name, totalPoints: points };
    })
    .sort((a, b) => b.totalPoints - a.totalPoints);
console.log(authorPointsList);