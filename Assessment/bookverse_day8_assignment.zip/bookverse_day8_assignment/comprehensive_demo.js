const data = require('./seed_data.json');

console.log('\n=== USER STORY 1: INDEXING AND QUERY OPTIMIZATION ===');
console.log('\n1. Creating Indexes:');
console.log('db.books.createIndex({ genre: 1 })');
console.log('db.books.createIndex({ authorId: 1 })');
console.log('db.books.createIndex({ "ratings.score": 1 })');

console.log('\n2. Bonus Compound Index:');
console.log('db.books.createIndex({ genre: 1, publicationYear: -1 })');

console.log('\n3. Example Explain Output for Genre Query:');
console.log({
    "queryPlanner": {
        "plannerVersion": 1,
        "namespace": "BookVerseDB.books",
        "indexFilterSet": false,
        "parsedQuery": { "genre": "Fiction" },
        "winningPlan": {
            "stage": "FETCH",
            "inputStage": {
                "stage": "IXSCAN",
                "keyPattern": { "genre": 1 },
                "indexName": "genre_1",
                "direction": "forward"
            }
        },
        "rejectedPlans": []
    },
    "executionStats": {
        "executionSuccess": true,
        "nReturned": 1,
        "executionTimeMillis": 0,
        "totalKeysExamined": 1,
        "totalDocsExamined": 1
    }
});

console.log('\n=== USER STORY 2: AGGREGATION FRAMEWORK ===');

// 1. Average rating per book
console.log('\n1. Average Rating per Book:');
const avgRatings = data.books.map(book => {
    const avg = book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length;
    return { _id: book.title, avgRating: avg };
}).sort((a, b) => b.avgRating - a.avgRating);
console.log(avgRatings);

// 2. Top 3 highest-rated books
console.log('\n2. Top 3 Highest-Rated Books:');
console.log(avgRatings.slice(0, 3));

// 3. Books per genre
console.log('\n3. Number of Books per Genre:');
const genreCounts = {};
data.books.forEach(book => {
    genreCounts[book.genre] = (genreCounts[book.genre] || 0) + 1;
});
console.log(Object.entries(genreCounts).map(([genre, count]) => ({ _id: genre, totalBooks: count })));

// 4. Authors with more than 2 books
console.log('\n4. Authors with More Than 2 Books:');
const authorCounts = {};
data.books.forEach(book => {
    authorCounts[book.authorId.$oid] = (authorCounts[book.authorId.$oid] || 0) + 1;
});
const authorsWithManyBooks = Object.entries(authorCounts)
    .filter(([_, count]) => count > 2)
    .map(([authorId, count]) => {
        const author = data.authors.find(a => a._id.$oid === authorId);
        return { authorName: author.name, bookCount: count };
    });
console.log(authorsWithManyBooks.length ? authorsWithManyBooks : 'No authors with more than 2 books found');

// 5. Total reward points by author
console.log('\n5. Total Reward Points by Author:');
const authorPoints = {};
data.books.forEach(book => {
    const authorId = book.authorId.$oid;
    const points = book.ratings.reduce((sum, r) => sum + r.score, 0);
    authorPoints[authorId] = (authorPoints[authorId] || 0) + points;
});
const authorPointsList = Object.entries(authorPoints)
    .map(([authorId, points]) => {
        const author = data.authors.find(a => a._id.$oid === authorId);
        return { authorName: author.name, totalPoints: points };
    })
    .sort((a, b) => b.totalPoints - a.totalPoints);
console.log(authorPointsList);

// Bonus Challenge
console.log('\nBONUS: Top-Rated Author by Average Book Score:');
const authorAvgScores = {};
data.books.forEach(book => {
    const authorId = book.authorId.$oid;
    const avgScore = book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length;
    if (!authorAvgScores[authorId]) {
        authorAvgScores[authorId] = { sum: 0, count: 0 };
    }
    authorAvgScores[authorId].sum += avgScore;
    authorAvgScores[authorId].count += 1;
});

const topAuthor = Object.entries(authorAvgScores)
    .map(([authorId, scores]) => {
        const author = data.authors.find(a => a._id.$oid === authorId);
        return {
            authorName: author.name,
            averageScore: scores.sum / scores.count
        };
    })
    .sort((a, b) => b.averageScore - a.averageScore)[0];

console.log(topAuthor);

console.log('\n=== USER STORY 3: MONGODB ATLAS CONNECTION ===');
console.log(`
To connect to MongoDB Atlas:
1. Create free cluster at cloud.mongodb.com
2. Create database 'BookVerseCloudDB'
3. Import collections using mongoimport:
   mongoimport --uri "mongodb+srv://<username>:<password>@cluster0.xxx.mongodb.net/BookVerseCloudDB" --collection books --file seed_data.json
4. Connect using Node.js:
   - Set MONGODB_ATLAS_URI environment variable
   - Run connectAtlas.js
`);