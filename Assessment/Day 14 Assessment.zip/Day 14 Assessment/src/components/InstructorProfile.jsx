import React from 'react';

const InstructorProfile = () => {
  return (
    <div className="container mt-4">
      <h2>Instructor Profile</h2>
      <p>Meet our expert instructor who will guide you through this course.</p>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">John Doe</h5>
          <p className="card-text">Experienced developer with 10+ years in web development.</p>
          <p className="card-text">Specializes in React, Node.js, and modern web technologies.</p>
        </div>
      </div>
    </div>
  );
};

export default InstructorProfile;
