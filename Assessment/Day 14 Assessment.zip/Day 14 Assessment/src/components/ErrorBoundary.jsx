import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
    console.error('Error caught by ErrorBoundary:', error, errorInfo);
    // In a real app, you might send this to a monitoring service
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="alert alert-danger m-4" role="alert">
          <h4 className="alert-heading">Oops! Something went wrong.</h4>
          <p>We apologize for the inconvenience. Please try refreshing the page or contact support if the problem persists.</p>
          <hr />
          <p className="mb-0">Error details have been logged for our team to review.</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
