import React from 'react';
import ReactDOM from 'react-dom';
import { motion } from 'framer-motion';

const Modal = ({ isOpen, onClose, children }) => {
  if (!isOpen) return null;

  const modalVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.3 } },
    exit: { opacity: 0, scale: 0.8, transition: { duration: 0.3 } }
  };

  const overlayVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.3 } },
    exit: { opacity: 0, transition: { duration: 0.3 } }
  };

  const modalRoot = document.getElementById('modal-root');

  return ReactDOM.createPortal(
    <motion.div
      className="modal-overlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
      }}
      variants={overlayVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
      onClick={onClose}
    >
      <motion.div
        className="modal-content bg-white p-4 rounded"
        style={{ maxWidth: '500px', width: '100%' }}
        variants={modalVariants}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          className="btn-close"
          aria-label="Close"
          onClick={onClose}
          style={{ float: 'right' }}
        ></button>
        {children}
      </motion.div>
    </motion.div>,
    modalRoot
  );
};

export default Modal;
