import React from 'react';

const ProductCard = ({ product }) => {
  // Simulate an error for demonstration
  if (product.id === 3) {
    throw new Error('Simulated error in ProductCard');
  }

  return (
    <div className="card m-2" style={{ width: '18rem' }}>
      <div className="card-body">
        <h5 className="card-title">{product.name}</h5>
        <p className="card-text">{product.description}</p>
        <p className="card-text">${product.price}</p>
      </div>
    </div>
  );
};

export default ProductCard;
