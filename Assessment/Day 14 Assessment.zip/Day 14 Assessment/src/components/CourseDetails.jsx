import React from 'react';

const CourseDetails = () => {
  return (
    <div className="container mt-4">
      <h2>Course Details</h2>
      <p>This is the detailed view of the course. Here you can find all the information about the course content, duration, and more.</p>
      <ul>
        <li>Duration: 4 weeks</li>
        <li>Level: Beginner</li>
        <li>Instructor: John Doe</li>
      </ul>
    </div>
  );
};

export default CourseDetails;
