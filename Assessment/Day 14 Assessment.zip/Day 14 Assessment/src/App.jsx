import React, { useState, Suspense, lazy } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import ErrorBoundary from './components/ErrorBoundary';
import StatsCard from './components/StatsCard';
import ProductCard from './components/ProductCard';
import Modal from './components/Modal';
import LoadingSpinner from './components/LoadingSpinner';

// Lazy load components
const CourseDetails = lazy(() => import('./components/CourseDetails'));
const InstructorProfile = lazy(() => import('./components/InstructorProfile'));

function App() {
  const [showCourseDetails, setShowCourseDetails] = useState(false);
  const [showInstructorProfile, setShowInstructorProfile] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [statsData, setStatsData] = useState([
    { id: 1, title: 'Total Users', value: 1234, lastUpdated: new Date().toLocaleString() },
    { id: 2, title: 'Active Sessions', value: 567, lastUpdated: new Date().toLocaleString() },
    { id: 3, title: 'Revenue', value: 89012, lastUpdated: new Date().toLocaleString() }
  ]);

  const products = [
    { id: 1, name: 'Product 1', description: 'Description 1', price: 10 },
    { id: 2, name: 'Product 2', description: 'Description 2', price: 20 },
    { id: 3, name: 'Product 3', description: 'Description 3', price: 30 }, // This will cause an error
    { id: 4, name: 'Product 4', description: 'Description 4', price: 40 }
  ];

  const simulateUpdate = () => {
    setStatsData(prevData =>
      prevData.map(card =>
        card.id === 1
          ? { ...card, value: card.value + Math.floor(Math.random() * 100), lastUpdated: new Date().toLocaleString() }
          : card
      )
    );
  };

  return (
    <div className="container mt-4">
      <h1 className="mb-4">React Advanced Concepts Demo</h1>

      {/* Challenge 1: Lazy Loading & Code Splitting */}
      <section className="mb-5">
        <h2>Challenge 1: Lazy Loading & Code Splitting</h2>
        <div className="mb-3">
          <button
            className="btn btn-primary me-2"
            onClick={() => setShowCourseDetails(!showCourseDetails)}
          >
            {showCourseDetails ? 'Hide' : 'View'} Course Details
          </button>
          <button
            className="btn btn-secondary"
            onClick={() => setShowInstructorProfile(!showInstructorProfile)}
          >
            {showInstructorProfile ? 'Hide' : 'View'} Instructor Profile
          </button>
        </div>
        <Suspense fallback={<LoadingSpinner />}>
          {showCourseDetails && <CourseDetails />}
          {showInstructorProfile && <InstructorProfile />}
        </Suspense>
      </section>

      {/* Challenge 2: Pure Components */}
      <section className="mb-5">
        <h2>Challenge 2: Pure Components</h2>
        <button className="btn btn-success mb-3" onClick={simulateUpdate}>
          Simulate Update
        </button>
        <div className="d-flex flex-wrap">
          {statsData.map(card => (
            <StatsCard
              key={card.id}
              title={card.title}
              value={card.value}
              lastUpdated={card.lastUpdated}
            />
          ))}
        </div>
      </section>

      {/* Challenge 3: Error Boundary */}
      <section className="mb-5">
        <h2>Challenge 3: Error Boundary</h2>
        <div className="d-flex flex-wrap">
          {products.map(product => (
            <ErrorBoundary key={product.id}>
              <ProductCard product={product} />
            </ErrorBoundary>
          ))}
        </div>
      </section>

      {/* Challenge 4: Portals */}
      <section className="mb-5">
        <h2>Challenge 4: Portals</h2>
        <button className="btn btn-info" onClick={() => setShowModal(true)}>
          Open Modal
        </button>
        <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
          <h3>Modal Content</h3>
          <p>This modal is rendered using React Portals and appears above all other content.</p>
          <p>It includes fade-in/out animations using Framer Motion.</p>
        </Modal>
      </section>
    </div>
  );
}

export default App;
