# TODO: Implement Clickable Book Image for Author Details on Separate Page

- [x] Install react-router-dom for routing.
- [x] Refactor App.js to use React Router with HomePage and AuthorPage components.
- [x] Update BookCard.js to make only the image clickable for navigating to author details page.
- [x] Run the development server (`npm start` in the `day2` directory) to test the app.
- [x] Verify that clicking on a book image navigates to a separate page displaying the author details.
- [x] Ensure the app builds without errors and the UI remains responsive.
