import React, { useRef, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useParams } from 'react-router-dom';
import BookList from './components/BookList';
import AuthorInfo from './components/AuthorInfo';
import SearchBar from './components/SearchBar';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

const sampleBooks = [
  { id:1, title:'The Silent Patient', author:'Alex Michaelides', price:1077, image:'https://covers.openlibrary.org/b/isbn/9781250301697-L.jpg', authorInfo: { name: 'Alex Michaelides', bio: 'Author of psychological thrillers.', top: ['The Silent Patient', 'The Maidens', 'The Fury'], image: 'https://covers.openlibrary.org/b/isbn/9781250301697-L.jpg' } },
  { id:2, title:'Where the Crawdads Sing', author:'Delia Owens', price:829, image:'https://covers.openlibrary.org/b/isbn/9780735219090-L.jpg', authorInfo: { name: 'Delia Owens', bio: 'Author known for nature-inspired stories.', top: ['Where the Crawdads Sing', 'Cry of the Kalahari', 'Secrets of the Savanna'], image: 'https://covers.openlibrary.org/b/isbn/9780735219090-L.jpg' } },
  { id:3, title:'Atomic Habits', author:'James Clear', price:1204, image:'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg', authorInfo: { name: 'James Clear', bio: 'Expert on habits and productivity.', top: ['Atomic Habits'], image: 'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg' } },
  { id:4, title:'The Alchemist', author:'Paulo Coelho', price:933, image:'https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg', authorInfo: { name: 'Paulo Coelho', bio: 'Brazilian author of inspirational novels.', top: ['The Alchemist', 'Veronika Decides to Die', 'The Zahir'], image: 'https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg' } },
  { id:5, title:'The Subtle Art of Not Giving a F*ck', author:'Mark Manson', price:1161, image:'https://covers.openlibrary.org/b/isbn/9780062457714-L.jpg', authorInfo: { name: 'Mark Manson', bio: 'Author on self-help and philosophy.', top: ['The Subtle Art of Not Giving a F*ck', 'Everything is F*cked', 'Models'], image: 'https://covers.openlibrary.org/b/isbn/9780062457714-L.jpg' } },
  { id:6, title:'Educated', author:'Tara Westover', price:892, image:'https://covers.openlibrary.org/b/isbn/9780399590504-L.jpg', authorInfo: { name: 'Tara Westover', bio: 'Memoirist and author.', top: ['Educated'], image: 'https://covers.openlibrary.org/b/isbn/9780399590504-L.jpg' } },
  { id:7, title:'Becoming', author:'Michelle Obama', price:1286, image:'https://covers.openlibrary.org/b/isbn/9781524763138-L.jpg', authorInfo: { name: 'Michelle Obama', bio: 'Former First Lady and author.', top: ['Becoming', 'The Light We Carry'], image: 'https://covers.openlibrary.org/b/isbn/9781524763138-L.jpg' } },
  { id:8, title:'The Power of Now', author:'Eckhart Tolle', price:1038, image:'https://covers.openlibrary.org/b/isbn/9781577314806-L.jpg', authorInfo: { name: 'Eckhart Tolle', bio: 'Spiritual teacher and author.', top: ['The Power of Now', 'A New Earth', 'Stillness Speaks'], image: 'https://covers.openlibrary.org/b/isbn/9781577314806-L.jpg' } },
  { id:9, title:'It Ends With Us', author:'Colleen Hoover', price:788, image:'https://covers.openlibrary.org/b/isbn/9781501110368-L.jpg', authorInfo: { name: 'Colleen Hoover', bio: 'Bestselling romance author.', top: ['It Ends With Us', 'Verity', 'Ugly Love'], image: 'https://covers.openlibrary.org/b/isbn/9781501110368-L.jpg' } },
  { id:10, title:'The 7 Habits of Highly Effective People', author:'Stephen R. Covey', price:1244, image:'https://covers.openlibrary.org/b/isbn/9780743269513-L.jpg', authorInfo: { name: 'Stephen R. Covey', bio: 'Author on personal development.', top: ['The 7 Habits of Highly Effective People', 'The 8th Habit', 'First Things First'], image: 'https://covers.openlibrary.org/b/isbn/9780743269513-L.jpg' } },
  { id:11, title:'Can’t Hurt Me', author:'David Goggins', price:1349, image:'https://covers.openlibrary.org/b/isbn/9781544512273-L.jpg', authorInfo: { name: 'David Goggins', bio: 'Motivational speaker and author.', top: ['Can’t Hurt Me', 'Never Finished'], image: 'https://covers.openlibrary.org/b/isbn/9781544512273-L.jpg' } },
  { id:12, title:'The Midnight Library', author:'Matt Haig', price:955, image:'https://covers.openlibrary.org/b/isbn/9780525559474-L.jpg', authorInfo: { name: 'Matt Haig', bio: 'Author of fiction and self-help.', top: ['The Midnight Library', 'How to Stop Time', 'The Humans'], image: 'https://covers.openlibrary.org/b/isbn/9780525559474-L.jpg' } },
  { id:13, title:'Rich Dad Poor Dad', author:'Robert T. Kiyosaki', price:912, image:'https://covers.openlibrary.org/b/isbn/9781612680194-L.jpg', authorInfo: { name: 'Robert T. Kiyosaki', bio: 'Entrepreneur and financial author.', top: ['Rich Dad Poor Dad', 'Cashflow Quadrant', 'Rich Dad\'s Guide to Investing'], image: 'https://covers.openlibrary.org/b/isbn/9781612680194-L.jpg' } },
  { id:14, title:'Think and Grow Rich', author:'Napoleon Hill', price:809, image:'https://covers.openlibrary.org/b/isbn/9780449214923-L.jpg', authorInfo: { name: 'Napoleon Hill', bio: 'Author on success and wealth.', top: ['Think and Grow Rich', 'Outwitting the Devil', 'The Law of Success'], image: 'https://covers.openlibrary.org/b/isbn/9780449214923-L.jpg' } },
  { id:15, title:'The Psychology of Money', author:'Morgan Housel', price:1121, image:'https://covers.openlibrary.org/b/isbn/9780857197689-L.jpg', authorInfo: { name: 'Morgan Housel', bio: 'Financial writer and author.', top: ['The Psychology of Money', 'Same as Ever'], image: 'https://covers.openlibrary.org/b/isbn/9780857197689-L.jpg' } },
  { id:16, title:'Verity', author:'Colleen Hoover', price:996, image:'https://covers.openlibrary.org/b/isbn/9781791392796-L.jpg', authorInfo: { name: 'Colleen Hoover', bio: 'Bestselling romance author.', top: ['It Ends With Us', 'Verity', 'Ugly Love'], image: 'https://covers.openlibrary.org/b/isbn/9781791392796-L.jpg' } },
  { id:17, title:'Sapiens: A Brief History of Humankind', author:'Yuval Noah Harari', price:1432, image:'https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg', authorInfo: { name: 'Yuval Noah Harari', bio: 'Historian and author.', top: ['Sapiens', 'Homo Deus', '21 Lessons for the 21st Century'], image: 'https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg' } },
  { id:18, title:'Dune', author:'Frank Herbert', price:1245, image:'https://covers.openlibrary.org/b/isbn/9780441172719-L.jpg', authorInfo: { name: 'Frank Herbert', bio: 'Science fiction author.', top: ['Dune', 'Dune Messiah', 'Children of Dune'], image: 'https://covers.openlibrary.org/b/isbn/9780441172719-L.jpg' } },
  { id:19, title:'The Book Thief', author:'Markus Zusak', price:988, image:'https://covers.openlibrary.org/b/isbn/9780375842207-L.jpg', authorInfo: { name: 'Markus Zusak', bio: 'Author of young adult fiction.', top: ['The Book Thief', 'Bridge of Clay', 'I Am the Messenger'], image: 'https://covers.openlibrary.org/b/isbn/9780375842207-L.jpg' } },
  { id:20, title:'1984', author:'George Orwell', price:746, image:'https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg', authorInfo: { name: 'George Orwell', bio: 'Dystopian novelist.', top: ['1984', 'Animal Farm', 'Down and Out in Paris and London'], image: 'https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg' } }
];

function HomePage() {
  const [query, setQuery] = useState('');
  const searchRef = useRef();
  const navigate = useNavigate();

  const filtered = sampleBooks.filter(b => b.title.toLowerCase().includes(query.toLowerCase()) || b.author.toLowerCase().includes(query.toLowerCase()));

  const handleSelect = (book) => {
    navigate(`/author/${book.id}`);
  };

  return (
    <div className="container-fluid">
      <div className="row justify-content-center">
        <div className="col-md-10 col-lg-8">
          <h2 className="text-center mb-4">BookVerse — Day 2 (Author Details & Styling)</h2>
          <div className="d-flex justify-content-center mb-4">
            <div className="input-group w-50">
              <SearchBar ref={searchRef} value={query} onChange={setQuery} />
              <button className="btn btn-outline-info" onClick={() => searchRef.current && searchRef.current.focus()}>Focus Search</button>
            </div>
          </div>

          <BookList books={filtered} onSelect={handleSelect} />
        </div>
      </div>
    </div>
  );
}

function AuthorPage() {
  const { id } = useParams();
  const book = sampleBooks.find(b => b.id === parseInt(id));

  if (!book) {
    return <div className="container text-center mt-5"><h3>Author not found</h3></div>;
  }

  return (
    <div className="container-fluid">
      <div className="row justify-content-center">
        <div className="col-md-10 col-lg-8">
          <h2 className="text-center mb-4">Author Details</h2>
          <AuthorInfo author={book.authorInfo} topBooks={book.authorInfo.top} />
          <div className="text-center mt-4">
            <button className="btn btn-primary" onClick={() => window.history.back()}>Back to Books</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/author/:id" element={<AuthorPage />} />
      </Routes>
    </Router>
  );
}
