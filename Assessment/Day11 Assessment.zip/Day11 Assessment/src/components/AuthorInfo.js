import React from 'react';
import PropTypes from 'prop-types';

export default function AuthorInfo({ author, topBooks = [] }) {
  return (
    <div className="card mt-4 shadow">
      <div className="card-body">
        <img src={author.image} alt={author.name} className="img-fluid mb-3 rounded" style={{ height: '150px', objectFit: 'cover' }} />
        <h5 className="card-title">About {author.name}</h5>
        <p className="card-text">{author.bio}</p>
        <h6>Top Works</h6>
        <ul className="list-group list-group-flush">
          {topBooks.slice(0, 3).map((t, idx) => <li key={idx} className="list-group-item">{t}</li>)}
        </ul>
      </div>
    </div>
  );
}

AuthorInfo.propTypes = {
  author: PropTypes.shape({
    name: PropTypes.string.isRequired,
    bio: PropTypes.string.isRequired
  }).isRequired,
  topBooks: PropTypes.arrayOf(PropTypes.string)
};
