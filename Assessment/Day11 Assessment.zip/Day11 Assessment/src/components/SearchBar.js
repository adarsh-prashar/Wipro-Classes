import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';

const SearchBar = forwardRef(({ value, onChange }, ref) => {
  return (
    <input
      ref={ref}
      aria-label="search"
      placeholder="Search by title or author..."
      value={value}
      onChange={e => onChange(e.target.value)}
      className="form-control"
    />
  );
});

SearchBar.propTypes = {
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};

export default SearchBar;
