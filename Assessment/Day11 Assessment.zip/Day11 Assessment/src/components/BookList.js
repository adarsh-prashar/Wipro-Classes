import React from 'react';
import PropTypes from 'prop-types';
import BookCard from './BookCard';

export default function BookList({ books, onSelect }) {
  return (
    <div className="row">
      {books.map(b => (
        <div key={b.id} className="col-md-6 col-lg-4 mb-4">
          <BookCard book={b} onClick={onSelect} />
        </div>
      ))}
    </div>
  );
}

BookList.propTypes = {
  books: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    authorInfo: PropTypes.object
  })).isRequired,
  onSelect: PropTypes.func.isRequired
};
