import React from 'react';

export default function BookCard({ book, onClick }) {
  return (
    <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '15px' }}>
      <img
        src={book.image}
        alt={book.title}
        className="card-img-top"
        style={{
          height: '250px',
          objectFit: 'cover',
          cursor: 'pointer',
          borderTopLeftRadius: '15px',
          borderTopRightRadius: '15px'
        }}
        onClick={() => onClick(book)} // 👈 Image click triggers author details
      />

      <div className="card-body">
        <h5 className="card-title">{book.title}</h5>
        <p className="card-text text-muted mb-1">{book.author}</p>
        <p className="fw-bold">${book.price}</p>
      </div>
    </div>
  );
}
