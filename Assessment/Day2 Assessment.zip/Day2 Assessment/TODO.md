# TODO List for Making Username Black in Welcome Message

- [x] Edit script.js to wrap the username in a span with black color in the welcome message.

# TODO List for Making Login Form Smaller

- [x] Add CSS to make login inputs and button smaller in index.html.

# TODO List for Adding Nav Bar in Welcome.html

- [x] Wrap header and top-buttons in a nav element in welcome.html.
- [x] Update CSS to style the nav bar with header on left and buttons on right.

# TODO List for Making Navbar Responsive on Mobile

- [x] Add CSS media queries to make navbar professional on small screens, preventing button compression.
