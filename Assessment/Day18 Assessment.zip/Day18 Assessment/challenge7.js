const fs = require('fs');

console.log('Starting read operation...');

// Read file asynchronously using callback
fs.readFile('data.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading file:', err);
        return;
    }

    console.log('File content:', data);

    // Add intentional delay using setTimeout before confirmation
    setTimeout(() => {
        console.log('Read operation completed');
    }, 1000); // 1 second delay
});
