const fs = require('fs').promises;

console.log('Starting file copy operation...');

// Chain promises: read from input.txt, then write to output.txt
fs.readFile('input.txt', 'utf8')
    .then(data => {
        console.log('Read content:', data);
        return fs.writeFile('output.txt', data);
    })
    .then(() => {
        console.log('File copied successfully!');
    })
    .catch(err => {
        console.error('Error during file copy:', err);
    });
