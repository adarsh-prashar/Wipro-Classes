const fs = require('fs').promises;

async function copyFile() {
    try {
        console.log('Starting file copy operation...');

        // Read content from input.txt
        const data = await fs.readFile('input.txt', 'utf8');
        console.log('Read content:', data);

        // Add artificial delay to simulate slow operation
        await new Promise(res => setTimeout(res, 1000));

        // Write content to output.txt
        await fs.writeFile('output.txt', data);

        console.log('File copied successfully!');
    } catch (err) {
        console.error('Error during file copy:', err);
    }
}

copyFile();
