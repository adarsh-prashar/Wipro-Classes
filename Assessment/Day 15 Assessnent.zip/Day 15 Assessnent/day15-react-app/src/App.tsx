import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { Provider } from 'react-redux';
import { store } from './store/store';
import Header from './components/Header';
import Home from './components/Home';
import WorkoutTracker from './components/WorkoutTracker';
import ProductManager from './components/ProductManager';
import OfflineBanner from './components/OfflineBanner';

const App: React.FC = () => {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <OfflineBanner />
        <Header />
        <Home />
        <WorkoutTracker />
        <ProductManager />
      </ThemeProvider>
    </Provider>
  );
};

export default App;
