import React from 'react';
import { useTheme } from '../contexts/ThemeContext';

const Home: React.FC = () => {
  const { theme } = useTheme();

  return (
    <div className={`home ${theme}`}>
      <h2>Welcome to the Home Page</h2>
      <p>This page demonstrates the theme context. Current theme: {theme}</p>
    </div>
  );
};

export default Home;
