import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState, AppDispatch } from '../store/store';
import { fetchProducts, updateProduct } from '../store/slices/productsSlice';
import { useTheme } from '../contexts/ThemeContext';

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
}

const ProductManager: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { items: products, loading, error } = useSelector((state: RootState) => state.products);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const { theme } = useTheme();

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
  };

  const handleSave = () => {
    if (editingProduct) {
      dispatch(updateProduct(editingProduct));
      setEditingProduct(null);
    }
  };

  const handleChange = (field: keyof Product, value: string | number) => {
    if (editingProduct) {
      setEditingProduct({ ...editingProduct, [field]: value });
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className={`product-manager ${theme}`}>
      <h2>Product Manager</h2>
      <ul>
        {products.map(product => (
          <li key={product.id}>
            {editingProduct?.id === product.id ? (
              <div>
                <input
                  type="text"
                  value={editingProduct.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
                <input
                  type="number"
                  value={editingProduct.price}
                  onChange={(e) => handleChange('price', parseFloat(e.target.value))}
                />
                <textarea
                  value={editingProduct.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                />
                <button onClick={handleSave}>Save</button>
                <button onClick={() => setEditingProduct(null)}>Cancel</button>
              </div>
            ) : (
              <div>
                <h3>{product.name}</h3>
                <p>Price: ₹{product.price}</p>
                <p>{product.description}</p>
                <button onClick={() => handleEdit(product)}>Edit</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductManager;
