import React, { useState, useEffect } from 'react';
import { useTimer } from '../hooks/useTimer';
import { useTheme } from '../contexts/ThemeContext';

const WorkoutTracker: React.FC = () => {
  const [sets, setSets] = useState(0);
  const restTime = 30; // 30 seconds rest
  const { time, isRunning, start, stop, reset } = useTimer();
  const { theme } = useTheme();

  useEffect(() => {
    if (time >= restTime && isRunning) {
      stop();
      alert('Rest time is over! Start your next set.');
      reset();
    }
  }, [time, isRunning, stop, reset]);

  const handleSetComplete = () => {
    setSets(prev => prev + 1);
    start();
  };

  const handleReset = () => {
    setSets(0);
    reset();
  };

  return (
    <div className={`workout-tracker ${theme}`}>
      <h2>Workout Tracker</h2>
      <div>
        <p>Sets completed: {sets}</p>
        <p>Rest time remaining: {Math.max(0, restTime - time)} seconds</p>
        <button onClick={handleSetComplete} disabled={isRunning}>
          Complete Set
        </button>
        <button onClick={stop} disabled={!isRunning}>
          Stop Timer
        </button>
        <button onClick={handleReset}>
          Reset Workout
        </button>
      </div>
    </div>
  );
};

export default WorkoutTracker;
