import React, { useState, useEffect } from 'react';
import { useTheme } from '../contexts/ThemeContext';

const OfflineBanner: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const { theme } = useTheme();

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className={`offline-banner ${theme}`}>
      <p>You are currently offline. Some features may not be available.</p>
    </div>
  );
};

export default OfflineBanner;
