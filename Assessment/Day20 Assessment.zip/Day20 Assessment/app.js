const express = require('express');
const app = express();
const PORT = 4000;

// Import routes
const coursesRouter = require('./routes/courses');

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to SkillSphere LMS API');
});

// Use courses routes
app.use('/courses', coursesRouter);

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
