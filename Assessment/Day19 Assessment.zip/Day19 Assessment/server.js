const express = require('express');
const cors = require('cors');
const bookRouter = require('./routes/books');

const app = express();
const PORT = 4000;

// Middleware
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON bodies

// Custom logging middleware with timestamp
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.url}`);
  next();
});

// Routes
app.get('/', (req, res) => {
  res.send('Welcome to Express Server');
});

app.get('/status', (req, res) => {
  res.json({ "server": "running", "uptime": "OK" });
});

app.get('/products', (req, res) => {
  const { name } = req.query;
  if (name) {
    res.json({ "query": name });
  } else {
    res.send('Please provide a product name');
  }
});

// Use book routes
app.use('/books', bookRouter);

// Global error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ "error": "Internal Server Error" });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ "error": "Route not found" });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
