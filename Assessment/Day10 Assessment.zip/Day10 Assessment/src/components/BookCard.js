import React from 'react';
import PropTypes from 'prop-types';

export default function BookCard({ book }) {
  return (
    <div className='card'>
      <img src={book.image} alt={book.title} style={{ width: '200px', height: '300px', objectFit: 'cover' }} />
      <h5>{book.title}</h5>
      <p><strong>Author:</strong> {book.author}</p>
      <p><strong>Price:</strong> ${book.price}</p>
    </div>
  );
}

BookCard.propTypes = {
  book: PropTypes.shape({
    id: PropTypes.number,
    title: PropTypes.string,
    author: PropTypes.string,
    price: PropTypes.number,
    image: PropTypes.string
  }).isRequired
};
