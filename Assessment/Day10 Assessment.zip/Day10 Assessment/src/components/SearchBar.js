import React from 'react';
export default function SearchBar({ value, onChange }) {
  return (
    <input
      aria-label="search"
      placeholder="Search by title or author..."
      value={value}
      onChange={e => onChange(e.target.value)}
      className="form-control"
    />
  );
}
