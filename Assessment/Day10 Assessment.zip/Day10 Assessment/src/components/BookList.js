import React from 'react';
import BookCard from './BookCard';

export default function BookList({ books, view }) {
  return (
    <div className={view === 'grid' ? 'book-grid' : 'book-list'}>
      {books.map(b => <BookCard key={b.id} book={b} />)}
    </div>
  );
}
