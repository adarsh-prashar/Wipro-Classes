import React, { useState } from 'react';
import BookList from './components/BookList';
import SearchBar from './components/SearchBar';

const sampleBooks = [
  { id:1, title:'The Silent Patient', author:'Alex Michaelides', price:12.99, image:'https://covers.openlibrary.org/b/isbn/9781250301697-L.jpg' },
{ id:2, title:'Where the Crawdads Sing', author:'Delia Owens', price:9.99, image:'https://covers.openlibrary.org/b/isbn/9780735219090-L.jpg' },
{ id:3, title:'Atomic Habits', author:'James Clear', price:14.5, image:'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg' },
{ id:4, title:'The Alchemist', author:'Paulo Coelho', price:11.25, image:'https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg' },
{ id:5, title:'The Subtle Art of Not Giving a F*ck', author:'Mark Manson', price:13.99, image:'https://covers.openlibrary.org/b/isbn/9780062457714-L.jpg' },
{ id:6, title:'Educated', author:'Tara Westover', price:10.75, image:'https://covers.openlibrary.org/b/isbn/9780399590504-L.jpg' },
{ id:7, title:'Becoming', author:'Michelle Obama', price:15.49, image:'https://covers.openlibrary.org/b/isbn/9781524763138-L.jpg' },
{ id:8, title:'The Power of Now', author:'Eckhart Tolle', price:12.5, image:'https://covers.openlibrary.org/b/isbn/9781577314806-L.jpg' },
{ id:9, title:'It Ends With Us', author:'Colleen Hoover', price:9.5, image:'https://covers.openlibrary.org/b/isbn/9781501110368-L.jpg' },
{ id:10, title:'The 7 Habits of Highly Effective People', author:'Stephen R. Covey', price:14.99, image:'https://covers.openlibrary.org/b/isbn/9780743269513-L.jpg' },
{ id:11, title:'Can’t Hurt Me', author:'David Goggins', price:16.25, image:'https://covers.openlibrary.org/b/isbn/9781544512273-L.jpg' },
{ id:12, title:'The Midnight Library', author:'Matt Haig', price:11.5, image:'https://covers.openlibrary.org/b/isbn/9780525559474-L.jpg' },
{ id:13, title:'Rich Dad Poor Dad', author:'Robert T. Kiyosaki', price:10.99, image:'https://covers.openlibrary.org/b/isbn/9781612680194-L.jpg' },
{ id:14, title:'Think and Grow Rich', author:'Napoleon Hill', price:9.75, image:'https://covers.openlibrary.org/b/isbn/9780449214923-L.jpg' },
{ id:15, title:'The Psychology of Money', author:'Morgan Housel', price:13.5, image:'https://covers.openlibrary.org/b/isbn/9780857197689-L.jpg' },
{ id:16, title:'Verity', author:'Colleen Hoover', price:12.0, image:'https://covers.openlibrary.org/b/isbn/9781791392796-L.jpg' },
{ id:17, title:'Sapiens: A Brief History of Humankind', author:'Yuval Noah Harari', price:17.25, image:'https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg' },
{ id:18, title:'Dune', author:'Frank Herbert', price:15.0, image:'https://covers.openlibrary.org/b/isbn/9780441172719-L.jpg' },
{ id:19, title:'The Book Thief', author:'Markus Zusak', price:11.9, image:'https://covers.openlibrary.org/b/isbn/9780375842207-L.jpg' },
{ id:20, title:'1984', author:'George Orwell', price:8.99, image:'https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg' }

];

export default function App() {
  const [view, setView] = useState('grid');
  const [query, setQuery] = useState('');

  const filtered = sampleBooks.filter(b =>
    b.title.toLowerCase().includes(query.toLowerCase()) ||
    b.author.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="container">
      <h2>BookVerse — Featured Books (Day 1)</h2>
      <div className="controls">
        <SearchBar value={query} onChange={setQuery} />
        <div>
          <button className="btn btn-outline-primary" onClick={() => setView('grid')}>Grid</button>{' '}
          <button className="btn btn-outline-secondary" onClick={() => setView('list')}>List</button>
        </div>
      </div>
      <BookList books={filtered} view={view} />
    </div>
  );
}
