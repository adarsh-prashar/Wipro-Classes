import React from "react";

function Logger({ numbers }) {
  const handleLog = () => {
    console.clear();
    console.log("Logging numbers using forEach:");
    numbers.forEach(item => console.log(item.value));
  };

  return <button onClick={handleLog}>Log Numbers to Console</button>;
}

export default Logger;
