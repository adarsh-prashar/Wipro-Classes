import React, { useEffect, useState } from "react";

function ConstructorDemo() {
  const [message, setMessage] = useState<string>("");

  useEffect(() => {
    function Person(this: any, name: string, age: number) {
      this.name = name;
      this.age = age;
      this.greet = function () {
        return `Hi, I'm ${this.name}, age ${this.age}`;
      };
    }

    const person1 = new (Person as any)("Avinash", 25);
    setMessage(person1.greet());
  }, []);

  return (
    <div>
      <h3>Constructor Demo</h3>
      <p>{message}</p>
    </div>
  );
}

export default ConstructorDemo;
