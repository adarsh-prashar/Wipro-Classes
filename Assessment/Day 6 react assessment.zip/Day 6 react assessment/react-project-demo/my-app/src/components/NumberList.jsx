import React from "react";

function NumberList({ numbers }) {
  return (
    <div className="number-list">
      <ul>
        {numbers.map((item, index) => (
          <li key={index}>{item.value}</li>
        ))}
      </ul>
    </div>
  );
}

export default NumberList;
