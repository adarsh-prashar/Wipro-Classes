import React from "react";
import { NumberItem } from "../types";

interface NumberListProps {
  numbers: NumberItem[];
}

function NumberList({ numbers }: NumberListProps) {
  return (
    <div className="number-list">
      <ul>
        {numbers.map((item, index) => (
          <li key={index}>{item.value}</li>
        ))}
      </ul>
    </div>
  );
}

export default NumberList;
