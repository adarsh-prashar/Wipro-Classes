import React, { useEffect, useState } from "react";

function ConstructorDemo() {
  const [message, setMessage] = useState("");

  useEffect(() => {
    function Person(name, age) {
      this.name = name;
      this.age = age;
      this.greet = function () {
        return `Hi, I'm ${this.name}, age ${this.age}`;
      };
    }

    const person1 = new Person("Adarsh", 24);
    setMessage(person1.greet());
  }, []);

  return (
    <div>
      <h3>Constructor Demo</h3>
      <p>{message}</p>
    </div>
  );
}

export default ConstructorDemo;
