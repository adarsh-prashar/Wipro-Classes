import React, { useEffect, useState } from "react";

function HoistingDemo() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const output = [];

    output.push("Variable and Function Hoisting Demo:");
    output.push("Before declaration (var): " + a); // undefined
    var a = 10;

    function greet() {
      output.push("Hello from a hoisted function!");
    }
    greet();

    setLogs(output);
  }, []);

  return (
    <div>
      <h3>Hoisting Demo</h3>
      <ul>
        {logs.map((line, i) => (
          <li key={i}>{line}</li>
        ))}
      </ul>
    </div>
  );
}

export default HoistingDemo;
