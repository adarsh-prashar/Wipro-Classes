import React, { useEffect, useState } from "react";

function HoistingDemo() {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const output: string[] = [];

    output.push("Variable and Function Hoisting Demo:");
    // @ts-ignore
    output.push("Before declaration (var): " + a); // undefined
    var a = 10;

    function greet() {
      output.push("Hello from a hoisted function!");
    }
    greet();

    setLogs(output);
  }, []);

  return (
    <div>
      <h3>Hoisting Demo</h3>
      <ul>
        {logs.map((line, i) => (
          <li key={i}>{line}</li>
        ))}
      </ul>
    </div>
  );
}

export default HoistingDemo;
