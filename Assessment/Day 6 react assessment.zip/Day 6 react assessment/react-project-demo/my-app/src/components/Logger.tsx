import React from "react";
import { NumberItem } from "../types";

interface LoggerProps {
  numbers: NumberItem[];
}

function Logger({ numbers }: LoggerProps) {
  const handleLog = () => {
    console.clear();
    console.log("Logging numbers using forEach:");
    numbers.forEach(item => console.log(item.value));
  };

  return <button onClick={handleLog}>Log Numbers to Console</button>;
}

export default Logger;
