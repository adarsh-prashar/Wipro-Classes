import React from "react";

interface FilterControlsProps {
  onFilter: () => void;
  onMap: () => void;
  onReset: () => void;
}

function FilterControls({ onFilter, onMap, onReset }: FilterControlsProps) {
  return (
    <div className="controls">
      <button onClick={onFilter}>Filter Even Numbers</button>
      <button onClick={onMap}>Double Numbers</button>
      <button onClick={onReset}>Reset Numbers</button>
    </div>
  );
}

export default FilterControls;
