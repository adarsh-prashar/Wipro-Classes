import React, { useState } from "react";
import NumberList from "./components/NumberList";
import FilterControls from "./components/FilterControls";
import Logger from "./components/Logger";
import HoistingDemo from "./components/HoistingDemo";
import ConstructorDemo from "./components/ConstructorDemo";
import "./App.css";

function App() {
  const originalNumbers = [1, 2, 3, 4, 5, 6, 7, 8].map(value => ({ value }));
  const [numbers, setNumbers] = useState(originalNumbers);

  // Filter even numbers
  const filterEven = () => setNumbers(prev => prev.filter(num => num.value % 2 === 0));

  // Map (double) numbers
  const doubleNumbers = () => setNumbers(prev => prev.map(num => ({ value: num.value * 2 })));

  // Reset numbers to original
  const resetNumbers = () => setNumbers(originalNumbers);

  return (
    <div className="app-container">
      <h1>JavaScript Concepts Demo</h1>

      <div className="section">
        <h3>Number List</h3>
        <NumberList numbers={numbers} />
      </div>

      <div className="section">
        <FilterControls onFilter={filterEven} onMap={doubleNumbers} onReset={resetNumbers} />
      </div>

      <div className="section">
        <Logger numbers={numbers} />
      </div>

      <div className="section">
        <HoistingDemo />
      </div>

      <div className="section">
        <ConstructorDemo />
      </div>
    </div>
  );
}

export default App;
