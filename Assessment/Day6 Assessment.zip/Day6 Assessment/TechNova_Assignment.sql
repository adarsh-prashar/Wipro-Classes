CREATE DATABASE IF NOT EXISTS TechNovaDB;
USE TechNovaDB;

CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(100) UNIQUE NOT NULL,
    Location VARCHAR(100)
);

CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M','F')),
    DOB DATE,
    HireDate DATE,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) UNIQUE NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,2) CHECK (Rating BETWEEN 0 AND 5),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

CREATE INDEX idx_emp_name ON Employee(EmpName);
CREATE INDEX idx_dept_id ON Employee(DeptID);

INSERT INTO Department VALUES
(101, 'IT', 'Bangalore'),
(102, 'HR', 'Delhi'),
(103, 'Finance', 'Mumbai'),
(104, 'Marketing', 'Chennai'),
(105, 'Operations', 'Pune');

INSERT INTO Employee VALUES
(1, 'Asha', 'F', '1990-07-12', '2018-06-10', 101),
(2, 'Raj', 'M', '1988-04-09', '2020-03-22', 102),
(3, 'Neha', 'F', '1995-01-15', '2021-08-05', 101),
(4, 'Karan', 'M', '1992-11-30', '2019-02-15', 103),
(5, 'Priya', 'F', '1993-09-25', '2022-04-18', 104);

INSERT INTO Project VALUES
(201, 'ERP Upgrade', 101, '2020-01-01', '2020-12-31'),
(202, 'HR Portal', 102, '2021-03-01', '2021-09-30'),
(203, 'Financial Audit', 103, '2022-05-01', '2022-10-31'),
(204, 'Brand Campaign', 104, '2023-01-15', '2023-06-30'),
(205, 'Logistics System', 105, '2022-07-01', '2023-01-01');

INSERT INTO Performance VALUES
(1, 201, 4.5, '2020-12-31'),
(2, 202, 3.8, '2021-09-30'),
(3, 201, 4.2, '2021-12-31'),
(4, 203, 4.7, '2022-10-31'),
(5, 204, 4.0, '2023-06-30');

INSERT INTO Reward VALUES
(1, '2023-01-01', 2500),
(2, '2023-02-01', 800),
(3, '2023-03-01', 2000),
(4, '2023-04-01', 3000),
(5, '2023-05-01', 1500);

UPDATE Employee SET DeptID = 103 WHERE EmpID = 3;
DELETE FROM Reward WHERE RewardAmount < 1000;

SELECT EmpName, HireDate FROM Employee WHERE HireDate > '2019-01-01';

SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

SELECT EmpName, TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age FROM Employee;

SELECT YEAR(RewardMonth) AS Year, SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE())
GROUP BY YEAR(RewardMonth);

SELECT e.EmpName, r.RewardAmount FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID WHERE r.RewardAmount > 2000;

SELECT e.EmpName, d.DeptName, p.ProjectName, pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

SELECT DeptName, EmpName, Rating
FROM (
    SELECT d.DeptName, e.EmpName, p.Rating,
           RANK() OVER (PARTITION BY d.DeptName ORDER BY p.Rating DESC) AS rnk
    FROM Performance p
    JOIN Employee e ON p.EmpID = e.EmpID
    JOIN Department d ON e.DeptID = d.DeptID
) ranked WHERE rnk = 1;

SELECT EmpName FROM Employee
WHERE EmpID NOT IN (SELECT EmpID FROM Reward);

START TRANSACTION;
INSERT INTO Employee VALUES (6, 'Sanjay', 'M', '1994-05-20', '2023-07-01', 101);
INSERT INTO Performance VALUES (6, 201, 4.3, '2023-12-31');
COMMIT;

CREATE OR REPLACE VIEW EmployeePerformanceView AS
SELECT e.EmpID, e.EmpName, d.DeptName, p.ProjectName, pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

DELIMITER //
CREATE PROCEDURE GetTopPerformers(IN deptName VARCHAR(100))
BEGIN
    SELECT e.EmpName, d.DeptName, AVG(pf.Rating) AS AvgRating
    FROM Employee e
    JOIN Department d ON e.DeptID = d.DeptID
    JOIN Performance pf ON e.EmpID = pf.EmpID
    WHERE d.DeptName = deptName
    GROUP BY e.EmpName, d.DeptName
    ORDER BY AvgRating DESC
    LIMIT 3;
END //

