const chalk = require('chalk');
const figlet = require('figlet');

console.log(chalk.blue(figlet.textSync('Welcome to Node.js')));
