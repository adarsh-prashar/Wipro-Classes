// Revealing Module Pattern
const FetchApp = (() => {
  // Configuration for API endpoints - easy to read and modify
  const config = {
    postsAPI: "https://jsonplaceholder.typicode.com/posts",
    todosAPI: "https://jsonplaceholder.typicode.com/todos",
  };

  // Local storage keys
  const LOCAL_POSTS_KEY = 'localPosts';
  const LOCAL_TODOS_KEY = 'localTodos';

  // Helper to get local data
  const getLocalPosts = () => JSON.parse(localStorage.getItem(LOCAL_POSTS_KEY) || '[]');
  const getLocalTodos = () => JSON.parse(localStorage.getItem(LOCAL_TODOS_KEY) || '[]');

  // Helper to save local data
  const saveLocalPosts = (posts) => localStorage.setItem(LOCAL_POSTS_KEY, JSON.stringify(posts));
  const saveLocalTodos = (todos) => localStorage.setItem(LOCAL_TODOS_KEY, JSON.stringify(todos));

  // ===== Fetch All Posts =====
  const fetchPosts = async () => {
    const postContainer = document.getElementById("posts-container");
    postContainer.innerHTML = "Loading posts...";
    try {
      const response = await fetch(config.postsAPI);
      if (!response.ok) throw new Error(`HTTP Error! Status: ${response.status}`);
      const posts = await response.json();
      displayPosts(posts);
    } catch (error) {
      postContainer.innerHTML = `<p class="error">❌ Error fetching posts: ${error.message}</p>`;
    }
  };

  // ===== Fetch All Todos =====
  const fetchTodos = async () => {
    const todoContainer = document.getElementById("todos-container");
    todoContainer.innerHTML = "Loading todos...";
    try {
      const response = await fetch(config.todosAPI);
      if (!response.ok) throw new Error(`HTTP Error! Status: ${response.status}`);
      const todos = await response.json();
      displayTodos(todos);
    } catch (error) {
      todoContainer.innerHTML = `<p class="error">❌ Error fetching todos: ${error.message}</p>`;
    }
  };

  // ===== Display Posts =====
  const displayPosts = (posts) => {
    const container = document.getElementById("posts-container");
    container.innerHTML = "";
    const localPosts = getLocalPosts();
    const allPosts = [...localPosts, ...posts];
    allPosts.forEach((post) => {
      const div = document.createElement("div");
      div.classList.add("post");
      div.innerHTML = `
        <h3>${post.title}</h3>
        <p>${post.body}</p>
        <small><strong>User ID:</strong> ${post.userId} | <strong>Post ID:</strong> ${post.id}</small>
      `;
      container.appendChild(div);
    });
  };

  // ===== Display Todos =====
  const displayTodos = (todos) => {
    const container = document.getElementById("todos-container");
    container.innerHTML = "";
    const localTodos = getLocalTodos();
    const allTodos = [...localTodos, ...todos];
    allTodos.forEach((todo) => {
      const div = document.createElement("div");
      div.classList.add("todo");
      if (todo.completed) div.classList.add("completed");
      div.innerHTML = `
        <p><strong>${todo.title}</strong></p>
        <p>Status: ${todo.completed ? "✅ Completed" : "🕓 Pending"}</p>
        <small><strong>User ID:</strong> ${todo.userId} | <strong>Todo ID:</strong> ${todo.id}</small>
      `;
      container.appendChild(div);
    });
  };

  // ===== Create Post =====
  const createPost = async (title, body) => {
    const newPost = {
      id: Date.now(), // Use timestamp as unique ID
      title,
      body,
      userId: 1,
    };
    const localPosts = getLocalPosts();
    localPosts.unshift(newPost); // Add to beginning
    saveLocalPosts(localPosts);
    displayPosts([]); // Refresh display
    logger.info(`New post created: ${newPost.title}`);
  };

  // ===== Create Todo =====
  const createTodo = async (title) => {
    const newTodo = {
      id: Date.now(), // Use timestamp as unique ID
      title,
      completed: false,
      userId: 1,
    };
    const localTodos = getLocalTodos();
    localTodos.unshift(newTodo); // Add to beginning
    saveLocalTodos(localTodos);
    displayTodos([]); // Refresh display
    logger.info(`New todo created: ${newTodo.title}`);
  };

  // ===== Public Methods =====
  return {
    init: () => {
      fetchPosts();
      fetchTodos();
    },
    reload: () => {
      fetchPosts();
      fetchTodos();
    },
    createPost,
    createTodo,
  };
})();

// Initialize app
document.addEventListener("DOMContentLoaded", () => {
  FetchApp.init();
  document.getElementById("refreshBtn").addEventListener("click", FetchApp.reload);

  // Event listeners for create forms
  document.getElementById("create-post-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const title = document.getElementById("post-title").value.trim();
    const body = document.getElementById("post-body").value.trim();
    if (title && body) {
      FetchApp.createPost(title, body);
      e.target.reset();
    }
  });

  document.getElementById("create-todo-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const title = document.getElementById("todo-title").value.trim();
    if (title) {
      FetchApp.createTodo(title);
      e.target.reset();
    }
  });
});
