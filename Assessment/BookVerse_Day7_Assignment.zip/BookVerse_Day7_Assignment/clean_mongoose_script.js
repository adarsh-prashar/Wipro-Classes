const mongoose = require('mongoose');

const uri = process.env.MONGODB_ATLAS_URI || "mongodb://localhost:27017/BookVerseDB";

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Connection error', err));

const authorSchema = new mongoose.Schema({ name: String, nationality: String, birthYear: Number });
const ratingSchema = new mongoose.Schema({ user: String, score: Number, comment: String });
const bookSchema = new mongoose.Schema({
  title: String,
  genre: String,
  publicationYear: Number,
  authorId: mongoose.Schema.Types.ObjectId,
  ratings: [ratingSchema]
});
const userSchema = new mongoose.Schema({ name: String, email: String, joinDate: Date });

const Author = mongoose.model('Author', authorSchema);
const Book = mongoose.model('Book', bookSchema);
const User = mongoose.model('User', userSchema);

async function seed() {
  await Author.deleteMany({});
  await Book.deleteMany({});
  await User.deleteMany({});

  const authors = await Author.insertMany([
    { name: "Isaac Asimov", nationality: "Russian-American", birthYear: 1920 },
    { name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
    { name: "George R.R. Martin", nationality: "American", birthYear: 1948 }
  ]);

  const users = await User.insertMany([
    { name: "Alice", email: "alice@example.com", joinDate: new Date("2025-01-10") },
    { name: "Bob", email: "bob@example.com", joinDate: new Date("2024-07-20") },
    { name: "Charlie", email: "charlie@example.com", joinDate: new Date("2025-04-01") }
  ]);

  await Book.insertMany([
    {
      title: "Foundation",
      genre: "Science Fiction",
      publicationYear: 1951,
      authorId: authors[0]._id,
      ratings: [
        { user: "Alice", score: 5, comment: "Brilliant world-building!" },
        { user: "Bob", score: 4, comment: "Classic sci-fi." }
      ]
    },
    {
      title: "Harry Potter and the Sorcerer's Stone",
      genre: "Fantasy",
      publicationYear: 1997,
      authorId: authors[1]._id,
      ratings: [
        { user: "Alice", score: 5, comment: "Magical!" },
        { user: "Charlie", score: 4, comment: "Loved it!" }
      ]
    },
    {
      title: "A Game of Thrones",
      genre: "Fantasy",
      publicationYear: 1996,
      authorId: authors[2]._id,
      ratings: [{ user: "Bob", score: 5, comment: "Epic storytelling." }]
    },
    {
      title: "The Caves of Steel",
      genre: "Science Fiction",
      publicationYear: 1953,
      authorId: authors[0]._id,
      ratings: [{ user: "Charlie", score: 4, comment: "Good detective twist." }]
    },
    {
      title: "Harry Potter and the Chamber of Secrets",
      genre: "Fantasy",
      publicationYear: 1998,
      authorId: authors[1]._id,
      ratings: []
    }
  ]);

  console.log('Seed data inserted successfully');
  mongoose.disconnect();
}

seed();