
use("BookVerseDB");



db.authors.insertMany([
  { _id: ObjectId(), name: "Isaac Asimov", nationality: "Russian-American", birthYear: 1920 },
  { _id: ObjectId(), name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
  { _id: ObjectId(), name: "George R.R. Martin", nationality: "American", birthYear: 1948 }
]);

db.users.insertMany([
  { _id: ObjectId(), name: "Alice", email: "alice@example.com", joinDate: ISODate("2025-01-10") },
  { _id: ObjectId(), name: "Bob", email: "bob@example.com", joinDate: ISODate("2024-07-20") },
  { _id: ObjectId(), name: "Charlie", email: "charlie@example.com", joinDate: ISODate("2025-04-01") }
]);

db.books.insertMany([
  {
    _id: ObjectId(),
    title: "Foundation",
    genre: "Science Fiction",
    publicationYear: 1951,
    authorId: db.authors.findOne({ name: "Isaac Asimov" })._id,
    ratings: [
      { user: "Alice", score: 5, comment: "Brilliant world-building!" },
      { user: "Bob", score: 4, comment: "Classic sci-fi." }
    ]
  },
  {
    _id: ObjectId(),
    title: "Harry Potter and the Sorcerer's Stone",
    genre: "Fantasy",
    publicationYear: 1997,
    authorId: db.authors.findOne({ name: "J.K. Rowling" })._id,
    ratings: [
      { user: "Alice", score: 5, comment: "Magical!" },
      { user: "Charlie", score: 4, comment: "Loved it!" }
    ]
  },
  {
    _id: ObjectId(),
    title: "A Game of Thrones",
    genre: "Fantasy",
    publicationYear: 1996,
    authorId: db.authors.findOne({ name: "George R.R. Martin" })._id,
    ratings: [{ user: "Bob", score: 5, comment: "Epic storytelling." }]
  },
  {
    _id: ObjectId(),
    title: "The Caves of Steel",
    genre: "Science Fiction",
    publicationYear: 1953,
    authorId: db.authors.findOne({ name: "Isaac Asimov" })._id,
    ratings: [{ user: "Charlie", score: 4, comment: "Good detective twist." }]
  },
  {
    _id: ObjectId(),
    title: "Harry Potter and the Chamber of Secrets",
    genre: "Fantasy",
    publicationYear: 1998,
    authorId: db.authors.findOne({ name: "J.K. Rowling" })._id,
    ratings: []
  }
]);

// ---------- User Story 2: CRUD Operations ----------

// Create: insert a new user
db.users.insertOne({ _id: ObjectId(), name: "David", email: "david@example.com", joinDate: ISODate("2025-05-01") });

// Read: retrieve all Science Fiction books
db.books.find({ genre: "Science Fiction" }).pretty();

// Update: change publicationYear for "Foundation"
db.books.updateOne({ title: "Foundation" }, { $set: { publicationYear: 1952 } });

// Delete: remove user "Charlie"
db.users.deleteOne({ name: "Charlie" });

// Update (push rating): add a rating to "A Game of Thrones"
db.books.updateOne(
  { title: "A Game of Thrones" },
  { $push: { ratings: { user: "David", score: 5, comment: "Amazing read!" } } }
);

// ---------- User Story 3: Querying & Filtering ----------

// 1) Books published after 2015
db.books.find({ publicationYear: { $gt: 2015 } });

// 2) Authors who wrote books in "Fantasy"
db.books.aggregate([
  { $match: { genre: "Fantasy" } },
  { $lookup: { from: "authors", localField: "authorId", foreignField: "_id", as: "authorDetails" } },
  { $unwind: "$authorDetails" },
  { $group: { _id: "$authorDetails._id", name: { $first: "$authorDetails.name" }, books: { $push: "$title" } } }
]);

// 3) Users who joined within last 6 months
const sixMonthsAgo = new Date(); sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
db.users.find({ joinDate: { $gte: sixMonthsAgo } });

// 4) Books with average rating > 4
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
  { $match: { avgRating: { $gt: 4 } } },
  { $sort: { avgRating: -1 } }
]);

// ---------- Bonus ----------

// Top 3 most-rated books (by number of ratings)
db.books.aggregate([
  { $project: { title: 1, ratingCount: { $size: { $ifNull: ["$ratings", []] } } } },
  { $sort: { ratingCount: -1 } },
  { $limit: 3 }
]);

print("Done: Day 7 assignment script executed (commands to run in mongo shell).");
