

const mongoose = require('mongoose');

const uri = process.env.MONGODB_ATLAS_URI || "mongodb+srv://adarsh:MyPass123@cluster0.abcd1.mongodb.net/BookVerseCloudDB?retryWrites=true&w=majority";

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch(err => console.error('Connection error', err));

const authorSchema = new mongoose.Schema({ name: String, nationality: String, birthYear: Number });
const ratingSchema = new mongoose.Schema({ user: String, score: Number, comment: String });
const bookSchema = new mongoose.Schema({
  title: String, genre: String, publicationYear: Number, authorId: mongoose.Schema.Types.ObjectId, ratings: [ratingSchema]
});
const userSchema = new mongoose.Schema({ name: String, email: String, joinDate: Date });

const Author = mongoose.model('Author', authorSchema);
const Book = mongoose.model('Book', bookSchema);
const User = mongoose.model('User', userSchema);

async function seed() {
  await Author.deleteMany({});
  await Book.deleteMany({});
  await User.deleteMany({});

  const authors = await Author.insertMany([
    { name: "Isaac Asimov", nationality: "Russian-American", birthYear: 1920 },
    { name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
    { name: "George R.R. Martin", nationality: "American", birthYear: 1948 }
  ]);

  const users = await User.insertMany([
    { name: "Alice", email: "alice@example.com", joinDate: new Date("2025-01-10") },
    { name: "Bob", email: "bob@example.com", joinDate: new Date("2024-07-20") },
    { name: "Charlie", email: "charlie@example.com", joinDate: new Date("2025-04-01") }
  ]);

  await Book.insertMany([
    {
      title: "Foundation",
      genre: "Science Fiction",
      publicationYear: 1951,
      authorId: authors[0]._id,
      ratings: [{ user: "Alice", score: 5, comment: "Brilliant" }]
    },
    {
      title: "Harry Potter and the Sorcerer's Stone",
      genre: "Fantasy",
      publicationYear: 1997,
      authorId: authors[1]._id,
      ratings: [{ user: "Bob", score: 4, comment: "Magical" }]
    },
    {
      title: "A Game of Thrones",
      genre: "Fantasy",
      publicationYear: 1996,
      authorId: authors[2]._id,
      ratings: []
    }
  ]);

  console.log('Seed data inserted via Mongoose');
  mongoose.disconnect();
}

seed();
