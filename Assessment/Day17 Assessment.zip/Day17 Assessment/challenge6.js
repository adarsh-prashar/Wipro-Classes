const EventEmitter = require('events');

class NotificationSystem extends EventEmitter {}

const notifier = new NotificationSystem();

// Register event listeners
notifier.on('userLoggedIn', (username) => {
    console.log(`User ${username} logged in.`);
});

notifier.on('userLoggedOut', (username) => {
    console.log(`User ${username} logged out.`);
});

notifier.on('sessionExpired', (username) => {
    console.log(`Session for user ${username} has expired.`);
});

// Emit events
notifier.emit('userLoggedIn', 'John');
notifier.emit('userLoggedOut', 'John');

// Bonus: Emit sessionExpired after 5 seconds
setTimeout(() => {
    notifier.emit('sessionExpired', 'John');
}, 5000);
