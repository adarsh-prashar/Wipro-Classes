const fs = require('fs').promises;

async function handleFile() {
    try {
        // Write user input to feedback.txt
        await fs.writeFile('feedback.txt', 'Node.js is awesome!');
        console.log('Data written successfully.');

        // Read and print the contents
        console.log('Reading file...');
        const data = await fs.readFile('feedback.txt', 'utf8');
        console.log(data);
    } catch (err) {
        console.error('Error:', err);
    }
}

handleFile();
