
class EventDashboard {
    constructor() {
        this.events = [];
        this.filteredEvents = [];
        this.categories = new Set();
        this.API_URL = './events.json';
        this.pollingInterval = 12000; // 12 seconds
        
        this.init();
    }

    async init() {
        try {
            await this.fetchEvents();
            this.setupDashboard();
            this.setupEventListeners();
            this.startLiveUpdates();
        } catch (error) {
            this.handleError(error);
        }
    }

    async fetchEvents() {
        try {
            const response = await fetch(this.API_URL);
            if (!response.ok) throw new Error('Network response was not ok');
            
            const { events } = await response.json();
            this.events = events;
            this.filteredEvents = [...events];
            this.categories = new Set(events.map(({ category }) => category));
            
            return events;
        } catch (error) {
            throw new Error(`Failed to fetch events: ${error.message}`);
        }
    }

    setupDashboard() {
        const dashboard = document.getElementById('events');
        if (!dashboard) return;

        const filterControls = `
            <div class="dashboard-controls mb-4">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" id="searchInput" class="form-control" 
                               placeholder="Search events...">
                    </div>
                    <div class="col-md-3">
                        <select id="categoryFilter" class="form-select">
                            <option value="">All Categories</option>
                            ${[...this.categories]
                                .map(cat => `<option value="${cat}">${cat}</option>`)
                                .join('')}
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="date" id="dateFilter" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <button id="clearFilters" class="btn btn-outline-secondary w-100">
                            Clear
                        </button>
                    </div>
                </div>
            </div>
            <div id="eventsContainer" class="row g-4"></div>
        `;

        dashboard.innerHTML = filterControls;
        this.renderEvents();
    }

    setupEventListeners() {
        const debounce = (fn, delay) => {
            let timeoutId;
            return (...args) => {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => fn.apply(this, args), delay);
            };
        };

        const filterEvents = debounce(() => this.filterEvents(), 300);

        ['searchInput', 'categoryFilter', 'dateFilter'].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.addEventListener('input', filterEvents);
        });

        const clearBtn = document.getElementById('clearFilters');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                ['searchInput', 'categoryFilter', 'dateFilter'].forEach(id => {
                    const element = document.getElementById(id);
                    if (element) element.value = '';
                });
                this.filteredEvents = [...this.events];
                this.renderEvents();
            });
        }

        document.addEventListener('click', e => {
            if (e.target.matches('[data-event-id]')) {
                const eventId = e.target.dataset.eventId;
                this.handleEventRegistration(eventId);
            }
        });
    }

    filterEvents() {
        const searchQuery = document.getElementById('searchInput')?.value.toLowerCase() ?? '';
        const categoryFilter = document.getElementById('categoryFilter')?.value ?? '';
        const dateFilter = document.getElementById('dateFilter')?.value ?? '';

        this.filteredEvents = this.events.filter(event => {
            const matchesSearch = !searchQuery || 
                event.title.toLowerCase().includes(searchQuery) || 
                event.description.toLowerCase().includes(searchQuery);
            
            const matchesCategory = !categoryFilter || event.category === categoryFilter;
            const matchesDate = !dateFilter || event.date.startsWith(dateFilter);

            return matchesSearch && matchesCategory && matchesDate;
        });

        this.renderEvents();
    }

    renderEvents() {
        const container = document.getElementById('eventsContainer');
        if (!container) return;

        if (this.filteredEvents.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center py-5">
                    <p class="text-muted">No events found matching your criteria.</p>
                </div>
            `;
            return;
        }

        const eventCards = this.filteredEvents.map(event => {
            const { id, title, date, category, description, image } = event;
            const formattedDate = new Date(date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });

            return `
                <div class="col-sm-6 col-lg-4">
                    <article class="card h-100 shadow-sm event-card">
                        <img src="${image}" class="card-img-top" alt="${title}">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h3 class="h5 card-title mb-0">${title}</h3>
                                <span class="badge bg-secondary">${category}</span>
                            </div>
                            <p class="card-text small text-muted mb-2">${formattedDate}</p>
                            <p class="card-text flex-grow-1">${description}</p>
                            <button class="btn btn-primary mt-2" data-event-id="${id}">
                                Register Now
                            </button>
                        </div>
                    </article>
                </div>
            `;
        }).join('');

        container.innerHTML = eventCards;
    }

    handleEventRegistration(eventId) {
        const event = this.events.find(e => e.id === eventId);
        if (!event) return;

        alert(`Registration started for: ${event.title}
Date: ${new Date(event.date).toLocaleDateString()}
Category: ${event.category}`);
    }

    startLiveUpdates() {
        setInterval(async () => {
            try {
                const newEvents = await this.fetchEvents();
                if (newEvents.length !== this.events.length) {
                    console.log('Events updated, refreshing view...');
                    this.filterEvents();
                }
            } catch (error) {
                console.error('Live update error:', error);
            }
        }, this.pollingInterval);
    }

    handleError(error) {
        console.error('Dashboard Error:', error);
        const dashboard = document.getElementById('events');
        if (dashboard) {
            dashboard.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    <h4 class="alert-heading">Error Loading Events</h4>
                    <p>${error.message}</p>
                    <hr>
                    <p class="mb-0">Please try refreshing the page.</p>
                </div>
            `;
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new EventDashboard();
});
      renderEvents(latest);
    }
  }, 12000);
}

// form validation for registration
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('regForm');
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    if(!form.checkValidity()){
      form.classList.add('was-validated');
      return;
    }
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const eventId = document.getElementById('eventSelect').value;
    alert(`Registered ${name} (${email}) for event ${eventId || '(none selected)'}`);
    form.reset();
    form.classList.remove('was-validated');
  });

  init();
});
