"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerService = exports.BaseService = exports.RegistrationStatus = exports.Role = void 0;
exports.runDemo = runDemo;
// Types and Enums
var Role;
(function (Role) {
    Role["Attendee"] = "Attendee";
    Role["Organizer"] = "Organizer";
    Role["Speaker"] = "Speaker";
    Role["VIP"] = "VIP";
})(Role || (exports.Role = Role = {}));
var RegistrationStatus;
(function (RegistrationStatus) {
    RegistrationStatus["Pending"] = "Pending";
    RegistrationStatus["Active"] = "Active";
    RegistrationStatus["Suspended"] = "Suspended";
    RegistrationStatus["Cancelled"] = "Cancelled";
})(RegistrationStatus || (exports.RegistrationStatus = RegistrationStatus = {}));
// Decorators
function Validate() {
    return function (target, propertyKey, descriptor) {
        var originalMethod = descriptor.value;
        descriptor.value = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var name = args[0], email = args[1];
            var errors = [];
            if (!name || name.length < 2) {
                errors.push('Name must be at least 2 characters');
            }
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email || !emailRegex.test(email)) {
                errors.push('Invalid email format');
            }
            if (errors.length > 0) {
                throw new Error("Validation failed: ".concat(errors.join(', ')));
            }
            return originalMethod.apply(this, args);
        };
        return descriptor;
    };
}
function Log(action) {
    return function (target, propertyKey, descriptor) {
        var original = descriptor.value;
        descriptor.value = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var timestamp = new Date().toISOString();
            console.log("[".concat(timestamp, "] ").concat(action, " - Method: ").concat(String(propertyKey)));
            try {
                var result = original.apply(this, args);
                console.log("[".concat(timestamp, "] ").concat(action, " completed successfully"));
                return result;
            }
            catch (error) {
                console.error("[".concat(timestamp, "] ").concat(action, " failed:"), error);
                throw error;
            }
        };
        return descriptor;
    };
}
// Abstract base class
var BaseService = /** @class */ (function () {
    function BaseService() {
        this.items = [];
    }
    BaseService.prototype.generateId = function () {
        return 'c' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    };
    return BaseService;
}());
exports.BaseService = BaseService;
// Main CustomerService class
var CustomerService = /** @class */ (function (_super) {
    __extends(CustomerService, _super);
    function CustomerService() {
        return _super.call(this) || this;
    }
    CustomerService.getInstance = function () {
        if (!CustomerService.instance) {
            CustomerService.instance = new CustomerService();
        }
        return CustomerService.instance;
    };
    CustomerService.prototype.register = function (name, email, role) {
        if (role === void 0) { role = Role.Attendee; }
        // Input validation
        if (!name || name.length < 2) {
            throw new Error('Name must be at least 2 characters');
        }
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailRegex.test(email)) {
            throw new Error('Invalid email format');
        }
        // Check for existing email
        if (this.findByEmail(email)) {
            throw new Error('Email already registered');
        }
        // Create new customer
        var customer = {
            id: this.generateId(),
            name: name,
            email: email,
            role: role,
            status: RegistrationStatus.Pending,
            registeredOn: new Date(),
            meta: [0, '', new Date()]
        };
        // Validate and save
        var _a = this.validate(customer), isValid = _a[0], errors = _a[1];
        if (!isValid) {
            throw new Error("Invalid customer data: ".concat(errors.join(', ')));
        }
        this.items.push(customer);
        // Log the registration
        console.log("[".concat(new Date().toISOString(), "] New customer registered: ").concat(name, " (").concat(email, ")"));
        return customer;
    };
    CustomerService.prototype.validate = function (customer) {
        var errors = [];
        if (!customer.name || customer.name.length < 2) {
            errors.push('Invalid name');
        }
        if (!customer.email || !customer.email.includes('@')) {
            errors.push('Invalid email');
        }
        return [errors.length === 0, errors];
    };
    CustomerService.prototype.updateStatus = function (customerId, status) {
        var customer = this.findById(customerId);
        if (!customer)
            return false;
        // Log status change
        console.log("[".concat(new Date().toISOString(), "] Customer ").concat(customerId, " status updated to ").concat(status));
        customer.status = status;
        customer.meta[1] = "Status updated to ".concat(status);
        customer.meta[2] = new Date();
        return true;
    };
    CustomerService.prototype.findByEmail = function (email) {
        return this.items.find(function (c) { return c.email.toLowerCase() === email.toLowerCase(); });
    };
    CustomerService.prototype.findById = function (id) {
        return this.items.find(function (c) { return c.id === id; });
    };
    // Custom iterator implementation
    CustomerService.prototype.getCustomersByRole = function (role) {
        var _i, _a, customer;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _i = 0, _a = this.items;
                    _b.label = 1;
                case 1:
                    if (!(_i < _a.length)) return [3 /*break*/, 4];
                    customer = _a[_i];
                    if (!(customer.role === role)) return [3 /*break*/, 3];
                    return [4 /*yield*/, customer];
                case 2:
                    _b.sent();
                    _b.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/];
            }
        });
    };
    // Method using custom filter type
    CustomerService.prototype.findCustomers = function (filter) {
        return this.items.filter(filter);
    };
    // Example of tuple usage in statistics
    CustomerService.prototype.getStatistics = function () {
        var totalCustomers = this.items.length;
        var activeCustomers = this.items.filter(function (c) { return c.status === RegistrationStatus.Active; }).length;
        var lastRegistration = this.items.length > 0
            ? new Date(Math.max.apply(Math, this.items.map(function (c) { return c.registeredOn.getTime(); })))
            : null;
        return [totalCustomers, activeCustomers, lastRegistration];
    };
    return CustomerService;
}(BaseService));
exports.CustomerService = CustomerService;
// Demo function to showcase the module's functionality
function runDemo() {
    var _a;
    try {
        var service = CustomerService.getInstance();
        // Register a new customer
        var customer = service.register('John Doe', 'john@example.com', Role.VIP);
        console.log('Registered:', customer);
        // Update status
        service.updateStatus(customer.id, RegistrationStatus.Active);
        // Use iterator to demonstrate VIP customers
        console.log('\nVIP Customers:');
        for (var _i = 0, _b = service.getCustomersByRole(Role.VIP); _i < _b.length; _i++) {
            var vipCustomer = _b[_i];
            console.log(vipCustomer);
        }
        // Use custom filter to show active customers
        var activeCustomers = service.findCustomers(function (c) { return c.status === RegistrationStatus.Active; });
        console.log('\nActive customers:', activeCustomers);
        // Get and display statistics
        var _c = service.getStatistics(), total = _c[0], active = _c[1], lastReg = _c[2];
        console.log("\nStatistics: ".concat(total, " total, ").concat(active, " active, ") +
            "Last registration: ".concat((_a = lastReg === null || lastReg === void 0 ? void 0 : lastReg.toLocaleString()) !== null && _a !== void 0 ? _a : 'None'));
    }
    catch (error) {
        if (error instanceof Error) {
            console.error('Error in demo:', error.message);
        }
        else {
            console.error('Unknown error in demo');
        }
    }
}
// Auto-run demo when file is executed directly
runDemo();
