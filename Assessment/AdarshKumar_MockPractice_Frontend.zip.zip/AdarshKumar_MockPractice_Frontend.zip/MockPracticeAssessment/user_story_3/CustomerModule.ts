// Types and Enums
export enum Role {
    Attendee = 'Attendee',
    Organizer = 'Organizer',
    Speaker = 'Speaker',
    VIP = 'VIP'
}

export enum RegistrationStatus {
    Pending = 'Pending',
    Active = 'Active',
    Suspended = 'Suspended',
    Cancelled = 'Cancelled'
}

// Type for validation results
type ValidationResult = [boolean, string[]];

// Interface definitions
export interface IAddress {
    street: string;
    city: string;
    postcode: string;
    country: string;
}

export interface ICustomerBase {
    id: string;
    name: string;
    email: string;
}

export interface ICustomer extends ICustomerBase {
    role: Role;
    status: RegistrationStatus;
    registeredOn: Date;
    address?: IAddress;
    meta: CustomerMeta; // Tuple type
}

// Custom types
type CustomerMeta = [number, string, Date]; // [visitCount, notes, lastVisit]
type CustomerFilter = (customer: ICustomer) => boolean;

// Method Decorator Types
type MethodDecorator = <T>(target: Object, propertyKey: string | symbol, descriptor: TypedPropertyDescriptor<T>) => TypedPropertyDescriptor<T> | void;

// Decorators
function Validate(): MethodDecorator {
    return function(target: Object, propertyKey: string | symbol, descriptor: PropertyDescriptor): PropertyDescriptor {
        const originalMethod = descriptor.value;
        
        descriptor.value = function(...args: any[]) {
            const [name, email] = args;
            const errors: string[] = [];
            
            if (!name || name.length < 2) {
                errors.push('Name must be at least 2 characters');
            }
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email || !emailRegex.test(email)) {
                errors.push('Invalid email format');
            }
            
            if (errors.length > 0) {
                throw new Error(`Validation failed: ${errors.join(', ')}`);
            }
            
            return originalMethod.apply(this, args);
        };
        
        return descriptor;
    };
}

function Log(action: string): MethodDecorator {
    return function(target: Object, propertyKey: string | symbol, descriptor: PropertyDescriptor): PropertyDescriptor {
        const original = descriptor.value;
        
        descriptor.value = function(...args: any[]) {
            const timestamp = new Date().toISOString();
            console.log(`[${timestamp}] ${action} - Method: ${String(propertyKey)}`);
            
            try {
                const result = original.apply(this, args);
                console.log(`[${timestamp}] ${action} completed successfully`);
                return result;
            } catch (error) {
                console.error(`[${timestamp}] ${action} failed:`, error);
                throw error;
            }
        };
        
        return descriptor;
    };
}

// Abstract base class
export abstract class BaseService<T> {
    protected items: T[] = [];
    
    abstract validate(item: T): ValidationResult;
    
    protected generateId(): string {
        return 'c' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    }
}

// Main CustomerService class
export class CustomerService extends BaseService<ICustomer> {
    private static instance: CustomerService;
    
    private constructor() {
        super();
    }
    
    static getInstance(): CustomerService {
        if (!CustomerService.instance) {
            CustomerService.instance = new CustomerService();
        }
        return CustomerService.instance;
    }
    
    register(name: string, email: string, role: Role = Role.Attendee): ICustomer {
        // Input validation
        if (!name || name.length < 2) {
            throw new Error('Name must be at least 2 characters');
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailRegex.test(email)) {
            throw new Error('Invalid email format');
        }
        
        // Check for existing email
        if (this.findByEmail(email)) {
            throw new Error('Email already registered');
        }
        
        // Create new customer
        const customer: ICustomer = {
            id: this.generateId(),
            name,
            email,
            role,
            status: RegistrationStatus.Pending,
            registeredOn: new Date(),
            meta: [0, '', new Date()]
        };
        
        // Validate and save
        const [isValid, errors] = this.validate(customer);
        if (!isValid) {
            throw new Error(`Invalid customer data: ${errors.join(', ')}`);
        }
        
        this.items.push(customer);
        
        // Log the registration
        console.log(`[${new Date().toISOString()}] New customer registered: ${name} (${email})`);
        
        return customer;
    }
    
    validate(customer: ICustomer): ValidationResult {
        const errors: string[] = [];
        
        if (!customer.name || customer.name.length < 2) {
            errors.push('Invalid name');
        }
        if (!customer.email || !customer.email.includes('@')) {
            errors.push('Invalid email');
        }
        
        return [errors.length === 0, errors];
    }
    
    updateStatus(customerId: string, status: RegistrationStatus): boolean {
        const customer = this.findById(customerId);
        if (!customer) return false;
        
        // Log status change
        console.log(`[${new Date().toISOString()}] Customer ${customerId} status updated to ${status}`);
        
        customer.status = status;
        customer.meta[1] = `Status updated to ${status}`;
        customer.meta[2] = new Date();
        return true;
    }
    
    findByEmail(email: string): ICustomer | undefined {
        return this.items.find(c => c.email.toLowerCase() === email.toLowerCase());
    }
    
    findById(id: string): ICustomer | undefined {
        return this.items.find(c => c.id === id);
    }
    
    // Custom iterator implementation
    *getCustomersByRole(role: Role): Generator<ICustomer> {
        for (const customer of this.items) {
            if (customer.role === role) {
                yield customer;
            }
        }
    }
    
    // Method using custom filter type
    findCustomers(filter: CustomerFilter): ICustomer[] {
        return this.items.filter(filter);
    }
    
    // Example of tuple usage in statistics
    getStatistics(): [number, number, Date | null] {
        const totalCustomers = this.items.length;
        const activeCustomers = this.items.filter(c => c.status === RegistrationStatus.Active).length;
        const lastRegistration = this.items.length > 0 
            ? new Date(Math.max(...this.items.map(c => c.registeredOn.getTime())))
            : null;
            
        return [totalCustomers, activeCustomers, lastRegistration];
    }
}

// Demo function to showcase the module's functionality
export function runDemo(): void {
    try {
        const service = CustomerService.getInstance();
        
        // Register a new customer
        const customer = service.register('John Doe', 'john@example.com', Role.VIP);
        console.log('Registered:', customer);
        
        // Update status
        service.updateStatus(customer.id, RegistrationStatus.Active);
        
        // Use iterator to demonstrate VIP customers
        console.log('\nVIP Customers:');
        for (const vipCustomer of service.getCustomersByRole(Role.VIP)) {
            console.log(vipCustomer);
        }
        
        // Use custom filter to show active customers
        const activeCustomers = service.findCustomers(c => c.status === RegistrationStatus.Active);
        console.log('\nActive customers:', activeCustomers);
        
        // Get and display statistics
        const [total, active, lastReg] = service.getStatistics();
        console.log(
            `\nStatistics: ${total} total, ${active} active, ` +
            `Last registration: ${lastReg?.toLocaleString() ?? 'None'}`
        );
    } catch (error) {
        if (error instanceof Error) {
            console.error('Error in demo:', error.message);
        } else {
            console.error('Unknown error in demo');
        }
    }
}

// Auto-run demo when file is executed directly
runDemo();
