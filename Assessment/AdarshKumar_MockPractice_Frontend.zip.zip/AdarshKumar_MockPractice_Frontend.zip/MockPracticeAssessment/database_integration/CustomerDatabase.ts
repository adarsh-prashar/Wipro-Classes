import mysql from 'mysql2/promise';
import { ICustomer as Customer, Role, RegistrationStatus } from '../user_story_3/CustomerModule';

// Database configuration interface
interface DbConfig {
    host: string;
    user: string;
    password: string;
    database: string;
}

export class CustomerDatabase {
    private static instance: CustomerDatabase;
    private connection: mysql.Connection | null = null;
    
    private constructor() {}

    static getInstance(): CustomerDatabase {
        if (!CustomerDatabase.instance) {
            CustomerDatabase.instance = new CustomerDatabase();
        }
        return CustomerDatabase.instance;
    }

    // Initialize database connection
    async connect(config: DbConfig): Promise<void> {
        try {
            this.connection = await mysql.createConnection(config);
            console.log('Successfully connected to MySQL database');
            await this.initializeTable();
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Database connection failed: ${error.message}`);
            }
            throw error;
        }
    }

    // Initialize customers table if it doesn't exist
    private async initializeTable(): Promise<void> {
        if (!this.connection) throw new Error('Database not connected');

        const createTableQuery = `
            CREATE TABLE IF NOT EXISTS customers (
                id VARCHAR(36) PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                role ENUM('REGULAR', 'VIP', 'ADMIN') NOT NULL,
                status ENUM('PENDING', 'ACTIVE', 'SUSPENDED') NOT NULL,
                registrationDate DATETIME NOT NULL
            )
        `;

        try {
            await this.connection.execute(createTableQuery);
            console.log('Customers table initialized');
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Table initialization failed: ${error.message}`);
            }
            throw error;
        }
    }

    // Create - Insert a new customer
    async createCustomer(customer: Customer): Promise<void> {
        if (!this.connection) throw new Error('Database not connected');

        const query = `
            INSERT INTO customers (id, name, email, role, status, registrationDate)
            VALUES (?, ?, ?, ?, ?, NOW())
        `;

        try {
            await this.connection.execute(query, [
                customer.id,
                customer.name,
                customer.email,
                Role[customer.role],
                RegistrationStatus[customer.status]
            ]);
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to create customer: ${error.message}`);
            }
            throw error;
        }
    }

    // Read - Get all customers
    async getAllCustomers(): Promise<Customer[]> {
        if (!this.connection) throw new Error('Database not connected');

        try {
            const [rows] = await this.connection.execute('SELECT * FROM customers');
            return (rows as any[]).map(row => ({
                id: row.id,
                name: row.name,
                email: row.email,
                role: Role[row.role as keyof typeof Role],
                status: RegistrationStatus[row.status as keyof typeof RegistrationStatus],
                registeredOn: new Date(row.registrationDate),
                meta: [0, '', new Date(row.registrationDate)]
            }));
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to fetch customers: ${error.message}`);
            }
            throw error;
        }
    }

    // Read - Get customer by ID
    async getCustomerById(id: string): Promise<Customer | null> {
        if (!this.connection) throw new Error('Database not connected');

        try {
            const [rows] = await this.connection.execute(
                'SELECT * FROM customers WHERE id = ?',
                [id]
            );
            
            const customers = rows as any[];
            if (customers.length === 0) return null;

            const row = customers[0];
            return {
                id: row.id,
                name: row.name,
                email: row.email,
                role: Role[row.role as keyof typeof Role],
                status: RegistrationStatus[row.status as keyof typeof RegistrationStatus],
                registeredOn: new Date(row.registrationDate),
                meta: [0, '', new Date(row.registrationDate)]
            };
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to fetch customer: ${error.message}`);
            }
            throw error;
        }
    }

    // Update - Update customer status
    async updateCustomerStatus(id: string, status: RegistrationStatus): Promise<void> {
        if (!this.connection) throw new Error('Database not connected');

        try {
            const [result] = await this.connection.execute(
                'UPDATE customers SET status = ? WHERE id = ?',
                [RegistrationStatus[status], id]
            );

            const updateResult = result as mysql.ResultSetHeader;
            if (updateResult.affectedRows === 0) {
                throw new Error(`Customer with ID ${id} not found`);
            }
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to update customer status: ${error.message}`);
            }
            throw error;
        }
    }

    // Delete - Remove a customer
    async deleteCustomer(id: string): Promise<void> {
        if (!this.connection) throw new Error('Database not connected');

        try {
            const [result] = await this.connection.execute(
                'DELETE FROM customers WHERE id = ?',
                [id]
            );

            const deleteResult = result as mysql.ResultSetHeader;
            if (deleteResult.affectedRows === 0) {
                throw new Error(`Customer with ID ${id} not found`);
            }
        } catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to delete customer: ${error.message}`);
            }
            throw error;
        }
    }

    // Close database connection
    async disconnect(): Promise<void> {
        if (this.connection) {
            await this.connection.end();
            this.connection = null;
            console.log('Database connection closed');
        }
    }
}