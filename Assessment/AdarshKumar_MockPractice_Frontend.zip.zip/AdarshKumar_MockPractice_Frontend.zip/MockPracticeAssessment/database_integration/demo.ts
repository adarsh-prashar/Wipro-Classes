import { CustomerDatabase } from './CustomerDatabase';
import { Role, RegistrationStatus } from '../user_story_3/CustomerModule';
import { v4 as uuidv4 } from 'uuid';

async function demoDatabase() {
    const db = CustomerDatabase.getInstance();

    try {
        // Connect to database
        await db.connect({
            host: 'localhost',
            user: 'root',
            password: 'your_password',
            database: 'customer_management'
        });

        // Create a new customer
        const newCustomer = {
            id: uuidv4(),
            name: 'Jane Smith',
            email: 'jane@example.com',
            role: Role.VIP,
            status: RegistrationStatus.Pending,
            registeredOn: new Date(),
            meta: [0, '', new Date()] as [number, string, Date]
        };

        console.log('\n1. Creating new customer...');
        await db.createCustomer(newCustomer);
        console.log('Customer created successfully');

        // Read all customers
        console.log('\n2. Reading all customers...');
        const allCustomers = await db.getAllCustomers();
        console.log('All customers:', allCustomers);

        // Read specific customer
        console.log('\n3. Reading customer by ID...');
        const customer = await db.getCustomerById(newCustomer.id);
        console.log('Found customer:', customer);

        // Update customer status
        console.log('\n4. Updating customer status...');
        await db.updateCustomerStatus(newCustomer.id, RegistrationStatus.Active);
        console.log('Customer status updated');

        // Verify update
        const updatedCustomer = await db.getCustomerById(newCustomer.id);
        console.log('Updated customer:', updatedCustomer);

        // Delete customer
        console.log('\n5. Deleting customer...');
        await db.deleteCustomer(newCustomer.id);
        console.log('Customer deleted');

        // Verify deletion
        const remainingCustomers = await db.getAllCustomers();
        console.log('Remaining customers:', remainingCustomers);

    } catch (error) {
        if (error instanceof Error) {
            console.error('Demo failed:', error.message);
        } else {
            console.error('Demo failed with unknown error');
        }
    } finally {
        await db.disconnect();
    }
}

// Run the demo
demoDatabase();