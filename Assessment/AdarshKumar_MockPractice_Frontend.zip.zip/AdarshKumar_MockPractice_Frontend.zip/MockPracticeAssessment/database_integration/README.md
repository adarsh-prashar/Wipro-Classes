# Customer Management Database Integration

This module provides MySQL database integration for the customer management system.

## Features

- Full CRUD operations for customer management
- TypeScript support with type safety
- Error handling and input validation
- Connection management with singleton pattern
- Automatic table creation and schema management

## Prerequisites

1. MySQL Server installed and running
2. Node.js and npm installed
3. TypeScript knowledge for development

## Setup Instructions

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create MySQL database:
   ```sql
   CREATE DATABASE customer_management;
   ```

3. Configure database connection:
   Update the database configuration in `demo.ts` with your MySQL credentials:
   ```typescript
   {
       host: 'localhost',
       user: 'your_username',
       password: 'your_password',
       database: 'customer_management'
   }
   ```

4. Build the project:
   ```bash
   npm run build
   ```

5. Run the demo:
   ```bash
   npm start
   ```

## Usage Example

```typescript
import { CustomerDatabase } from './CustomerDatabase';

async function main() {
    const db = CustomerDatabase.getInstance();
    
    try {
        await db.connect({
            host: 'localhost',
            user: 'root',
            password: 'your_password',
            database: 'customer_management'
        });

        // Create a customer
        await db.createCustomer({
            id: 'unique-id',
            name: 'John Doe',
            email: 'john@example.com',
            role: Role.REGULAR,
            status: RegistrationStatus.PENDING,
            registrationDate: new Date()
        });

        // Get all customers
        const customers = await db.getAllCustomers();
        console.log(customers);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await db.disconnect();
    }
}
```

## Error Handling

The module includes comprehensive error handling:
- Connection errors
- Query errors
- Input validation
- Type safety with TypeScript

All operations throw typed errors that can be caught and handled appropriately.

## Security Notes

1. Never commit database credentials to version control
2. Use environment variables for sensitive data in production
3. Implement proper input validation before database operations
4. Consider implementing connection pooling for production use

## Contributing

1. Ensure all TypeScript types are properly defined
2. Maintain error handling patterns
3. Add unit tests for new features
4. Follow existing code style and patterns