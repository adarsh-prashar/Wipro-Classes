"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerDatabase = void 0;
var promise_1 = require("mysql2/promise");
var CustomerModule_1 = require("../user_story_3/CustomerModule");
var CustomerDatabase = /** @class */ (function () {
    function CustomerDatabase() {
        this.connection = null;
    }
    CustomerDatabase.getInstance = function () {
        if (!CustomerDatabase.instance) {
            CustomerDatabase.instance = new CustomerDatabase();
        }
        return CustomerDatabase.instance;
    };
    // Initialize database connection
    CustomerDatabase.prototype.connect = function (config) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, error_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 3, , 4]);
                        _a = this;
                        return [4 /*yield*/, promise_1.default.createConnection(config)];
                    case 1:
                        _a.connection = _b.sent();
                        console.log('Successfully connected to MySQL database');
                        return [4 /*yield*/, this.initializeTable()];
                    case 2:
                        _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _b.sent();
                        if (error_1 instanceof Error) {
                            throw new Error("Database connection failed: ".concat(error_1.message));
                        }
                        throw error_1;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Initialize customers table if it doesn't exist
    CustomerDatabase.prototype.initializeTable = function () {
        return __awaiter(this, void 0, void 0, function () {
            var createTableQuery, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        createTableQuery = "\n            CREATE TABLE IF NOT EXISTS customers (\n                id VARCHAR(36) PRIMARY KEY,\n                name VARCHAR(100) NOT NULL,\n                email VARCHAR(100) UNIQUE NOT NULL,\n                role ENUM('REGULAR', 'VIP', 'ADMIN') NOT NULL,\n                status ENUM('PENDING', 'ACTIVE', 'SUSPENDED') NOT NULL,\n                registrationDate DATETIME NOT NULL\n            )\n        ";
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute(createTableQuery)];
                    case 2:
                        _a.sent();
                        console.log('Customers table initialized');
                        return [3 /*break*/, 4];
                    case 3:
                        error_2 = _a.sent();
                        if (error_2 instanceof Error) {
                            throw new Error("Table initialization failed: ".concat(error_2.message));
                        }
                        throw error_2;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Create - Insert a new customer
    CustomerDatabase.prototype.createCustomer = function (customer) {
        return __awaiter(this, void 0, void 0, function () {
            var query, error_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        query = "\n            INSERT INTO customers (id, name, email, role, status, registrationDate)\n            VALUES (?, ?, ?, ?, ?, ?)\n        ";
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute(query, [
                                customer.id,
                                customer.name,
                                customer.email,
                                CustomerModule_1.Role[customer.role],
                                CustomerModule_1.RegistrationStatus[customer.status],
                                customer.registrationDate
                            ])];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_3 = _a.sent();
                        if (error_3 instanceof Error) {
                            throw new Error("Failed to create customer: ".concat(error_3.message));
                        }
                        throw error_3;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Read - Get all customers
    CustomerDatabase.prototype.getAllCustomers = function () {
        return __awaiter(this, void 0, void 0, function () {
            var rows, error_4;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute('SELECT * FROM customers')];
                    case 2:
                        rows = (_a.sent())[0];
                        return [2 /*return*/, rows.map(function (row) { return ({
                                id: row.id,
                                name: row.name,
                                email: row.email,
                                role: CustomerModule_1.Role[row.role],
                                status: CustomerModule_1.RegistrationStatus[row.status],
                                registrationDate: new Date(row.registrationDate)
                            }); })];
                    case 3:
                        error_4 = _a.sent();
                        if (error_4 instanceof Error) {
                            throw new Error("Failed to fetch customers: ".concat(error_4.message));
                        }
                        throw error_4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Read - Get customer by ID
    CustomerDatabase.prototype.getCustomerById = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var rows, customers, row, error_5;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute('SELECT * FROM customers WHERE id = ?', [id])];
                    case 2:
                        rows = (_a.sent())[0];
                        customers = rows;
                        if (customers.length === 0)
                            return [2 /*return*/, null];
                        row = customers[0];
                        return [2 /*return*/, {
                                id: row.id,
                                name: row.name,
                                email: row.email,
                                role: CustomerModule_1.Role[row.role],
                                status: CustomerModule_1.RegistrationStatus[row.status],
                                registrationDate: new Date(row.registrationDate)
                            }];
                    case 3:
                        error_5 = _a.sent();
                        if (error_5 instanceof Error) {
                            throw new Error("Failed to fetch customer: ".concat(error_5.message));
                        }
                        throw error_5;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Update - Update customer status
    CustomerDatabase.prototype.updateCustomerStatus = function (id, status) {
        return __awaiter(this, void 0, void 0, function () {
            var result, updateResult, error_6;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute('UPDATE customers SET status = ? WHERE id = ?', [CustomerModule_1.RegistrationStatus[status], id])];
                    case 2:
                        result = (_a.sent())[0];
                        updateResult = result;
                        if (updateResult.affectedRows === 0) {
                            throw new Error("Customer with ID ".concat(id, " not found"));
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        error_6 = _a.sent();
                        if (error_6 instanceof Error) {
                            throw new Error("Failed to update customer status: ".concat(error_6.message));
                        }
                        throw error_6;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Delete - Remove a customer
    CustomerDatabase.prototype.deleteCustomer = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var result, deleteResult, error_7;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection)
                            throw new Error('Database not connected');
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.connection.execute('DELETE FROM customers WHERE id = ?', [id])];
                    case 2:
                        result = (_a.sent())[0];
                        deleteResult = result;
                        if (deleteResult.affectedRows === 0) {
                            throw new Error("Customer with ID ".concat(id, " not found"));
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        error_7 = _a.sent();
                        if (error_7 instanceof Error) {
                            throw new Error("Failed to delete customer: ".concat(error_7.message));
                        }
                        throw error_7;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Close database connection
    CustomerDatabase.prototype.disconnect = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.connection) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.connection.end()];
                    case 1:
                        _a.sent();
                        this.connection = null;
                        console.log('Database connection closed');
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    return CustomerDatabase;
}());
exports.CustomerDatabase = CustomerDatabase;
