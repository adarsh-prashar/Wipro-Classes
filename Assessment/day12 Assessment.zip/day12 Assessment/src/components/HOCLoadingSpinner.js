import React from 'react';
export default function withLoading(Wrapped) {
  return function WithLoading({ loading, ...props }) {
    if (loading) return <div>Loading...</div>;
    return <Wrapped {...props} />;
  };
}
