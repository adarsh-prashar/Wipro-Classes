import React from 'react';
export default function RenderProp({ children }) {
  // children is a function
  return <div className="card" style={{padding:12}}>{children()}</div>;
}
