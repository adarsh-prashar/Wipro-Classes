import React from 'react';
import { Link } from 'react-router-dom';

export default function BookList({ books }) {
  return (
    <div className="book-grid">
      {books.map(b => (
        <div key={b.id} className="card" style={{padding:10}}>
          <img src={b.image} alt={b.title} style={{width: '150px', height: '150px', objectFit: 'cover'}} />
          <h5>{b.title}</h5>
          <p>{b.author}</p>
          <Link to={'/book/' + b.id}>Details</Link>
        </div>
      ))}
    </div>
  );
}
