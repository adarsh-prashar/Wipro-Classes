import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import booksData from '../books.json';

export default function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  useEffect(() => {
    const found = booksData.books.find(x => String(x.id) === String(id));
    setBook(found || null);
  }, [id]);
  if (!book) return <div>Book not found or loading...</div>;
  return (
    <div>
      <img src={book.image} alt={book.title} style={{width: '200px', height: '200px', objectFit: 'cover'}} />
      <h3>{book.title}</h3>
      <p><strong>Author:</strong> {book.author}</p>
      <p>{book.description}</p>
      <p><strong>Price:</strong> ${book.price}</p>
    </div>
  );
}
