import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import BookList from './components/BookList';
import BookDetails from './components/BookDetails';
import withLoading from './components/HOCLoadingSpinner';
import RenderProp from './components/RenderProp';
import booksData from './books.json';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

const ListWithLoading = withLoading(BookList);

function AppContent() {
  const location = useLocation();
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // load from local JSON
    setBooks(booksData.books || []);
    setLoading(false);
  }, []);

  return (
    <div className="container">
      <h2>BookVerse — Day 3 (Routing & Data)</h2>
      {location.pathname !== "/" && (
        <nav style={{marginBottom:12}}>
          <Link to="/">Home</Link>
        </nav>
      )}
      <TransitionGroup>
        <CSSTransition key={location.key} classNames="fade" timeout={300}>
          <Routes location={location}>
            <Route path="/" element={<ListWithLoading loading={loading} books={books} />} />
            <Route path="/book/:id" element={<BookDetails />} />
            <Route path="*" element={<div>Go to <Link to="/">Home</Link></div>} />
          </Routes>
        </CSSTransition>
      </TransitionGroup>

      <RenderProp>{() => <div style={{marginTop:12}}>Welcome! There are {books.length} books.</div>}</RenderProp>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
